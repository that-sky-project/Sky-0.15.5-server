# index.py
import json
import os
import uuid
import requests
import glob
import secrets
from flask import Flask, request, jsonify, g, send_from_directory
import time
from datetime import datetime
import importlib
import logging
import command

from route import account_bp, service_bp, chat_bp, license_bp, client_bp  # 导入所有蓝图

app = Flask(__name__)
app.json.ensure_ascii = False

# ---------- 注册蓝图 ----------
app.register_blueprint(account_bp)
app.register_blueprint(service_bp)
app.register_blueprint(chat_bp)
app.register_blueprint(license_bp)   # 卡密系统：/admin 管理页 + /key/verify 客户端校验
app.register_blueprint(client_bp)    # 客户端检查更新：GET /client/version

# ---------- 数据库初始化 ----------
# 使用统一的 db 模块（支持 MySQL/SQLite）
import db as database
database.init_db()

# ---------- 工具 ----------
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")

def load_config():
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return json.load(f)

# 确保 logs 目录存在
LOG_DIR = os.path.join(os.path.dirname(__file__), 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

# ============================================================
# 日志中间件（保留在 index.py）
# ============================================================
@app.before_request
def log_account_create_body():
    if request.endpoint == 'account.request_geonotes_for_n_friends':
        body = request.get_json(silent=True) or request.form.to_dict() or request.data.decode()
        headers = dict(request.headers)
        log_file = os.path.join(LOG_DIR, 'purchase_unlock.log')
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"{datetime.utcnow().isoformat()}Z\n")
            f.write("Headers:\n")
            f.write(json.dumps(headers, ensure_ascii=False, indent=2) + "\n")
            f.write("Body:\n")
            f.write(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
            f.write("-" * 40 + "\n")

@app.before_request
def get_friendslog():
    if request.endpoint == 'account.get_friends':
        body = request.get_json(silent=True) or request.form.to_dict() or request.data.decode()
        headers = dict(request.headers)
        log_file = os.path.join(LOG_DIR, 'purchase_unlock.log')
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"{datetime.utcnow().isoformat()}Z\n")
            f.write("Headers:\n")
            f.write(json.dumps(headers, ensure_ascii=False, indent=2) + "\n")
            f.write("Body:\n")
            f.write(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
            f.write("-" * 40 + "\n")

# ============================================================
# ★ 请求记录（排障开关，默认关）
#   config.json 里设 "log_requests": true 才生效；关掉就设 false。
#   为什么要有它：社交类问题（好友请求 / 给蜡烛的"接受"提示 / 对方装扮）
#   客户端走的不是 UDP，而是这些 HTTP 接口 —— 只有看到"客户端到底调了什么、
#   我们回了什么"，才能把请求/响应的结构对上。
#   日志：logs/requests.log（会增长，排障完记得关掉或清空）
# ============================================================
LOG_REQ_FILE = os.path.join(LOG_DIR, 'requests.log')
_SKIP_PREFIX = ('/dl/', '/admin', '/static', '/favicon')


@app.before_request
def wbsky_log_request_in():
    try:
        if not load_config().get("log_requests"):
            return
    except Exception:
        return
    p = request.path or ''
    if p.startswith(_SKIP_PREFIX):
        return
    try:
        body = request.get_data(cache=True) or b''
        txt = body.decode('utf-8', 'replace')
    except Exception:
        txt = ''
    if len(txt) > 1200:
        txt = txt[:1200] + '...<截断>'
    g.wbsky_req = "%s %s  body=%s" % (request.method, p, txt)


@app.after_request
def wbsky_log_request_out(resp):
    info = getattr(g, 'wbsky_req', None)
    if not info:
        return resp
    try:
        if getattr(resp, 'direct_passthrough', False):
            out = ' resp=<文件/流>'
        else:
            data = resp.get_data()
            if len(data) < 4096:
                out = ' resp=' + data.decode('utf-8', 'replace').replace('\n', ' ')
            else:
                out = ' resp=<%d bytes>' % len(data)
        with open(LOG_REQ_FILE, 'a', encoding='utf-8') as f:
            f.write("%s | %s | %s%s\n" % (datetime.utcnow().isoformat() + 'Z',
                                          info, resp.status_code, out))
    except Exception:
        pass
    return resp


# ============================================================
# 其他路由（非 /account/ 和 /service/）
# ============================================================

@app.route("/starwatch/auth/api/v1/auth", methods=["POST"])
def starwatch_auth_api_v1_auth():
    # 官方 that-sky-server：starwatch 认证成功返回空对象 {}
    # 之前返回 starwatch.json 里的"验证错误"结构 -> 客户端认证失败 ->
    # 不请求 find_previous_or_empty（中继地址）-> 不连 UDP -> 看不到人
    return jsonify({})

# ---------- 404 错误处理 ----------
# 返回空 JSON 而非 HTML，防止客户端解析失败导致按钮消失

@app.errorhandler(404)
def not_found_error(e):
    return jsonify({}), 200

@app.errorhandler(500)
def internal_error(e):
    return jsonify({}), 200

# ---------- 根级 Catch-All 兜底路由 ----------
# 任何未匹配的 POST 请求返回空 JSON

@app.route("/", defaults={"path": ""}, methods=["POST", "GET"])
@app.route("/<path:path>", methods=["POST", "GET"])
def root_catch_all(path):
    return jsonify({}), 200

# ---------- 启动 ----------
if __name__ == '__main__':
    with app.app_context():
        # 检查 SSL 证书是否存在，存在则启用 HTTPS，否则用 HTTP
        cert_file = 'fullchain.pem'
        key_file = 'privkey.key'
        if os.path.isfile(cert_file) and os.path.isfile(key_file):
            app.run(ssl_context=(cert_file, key_file), debug=True, host='0.0.0.0', port=2999)
        else:
            app.run(debug=True, host='0.0.0.0', port=2999)
