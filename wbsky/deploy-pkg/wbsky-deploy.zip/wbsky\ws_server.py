#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wbsky Player WebSocket 服务器（that-sky 方式）
- 接受 /account/ws WebSocket 连接（任何路径均可）
- 纯握手 + 保持连接（不解析 MQTT！客户端不会崩）
- 空闲 ping 保持活性
用法: python3 ws_server.py [port]  默认 9002
"""
import socket
import base64
import hashlib
import struct
import threading
import sys
import time
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', datefmt='%H:%M:%S')

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9002
HOST = '0.0.0.0'

clients = set()
clients_lock = threading.Lock()


def ws_handshake(headers):
    key = ''
    for line in headers:
        if line.lower().startswith('sec-websocket-key:'):
            key = line.split(':', 1)[1].strip()
            break
    if not key:
        raise ValueError('no Sec-WebSocket-Key')
    accept = base64.b64encode(
        hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()
    ).decode()
    return (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Accept: " + accept + "\r\n"
        "\r\n"
    )


def read_exact(conn, n):
    data = b''
    while len(data) < n:
        chunk = conn.recv(n - len(data))
        if not chunk:
            raise ConnectionError('closed')
        data += chunk
    return data


def read_ws_frame(conn):
    hdr = read_exact(conn, 2)
    opcode = hdr[0] & 0x0F
    masked = (hdr[1] >> 7) & 1
    length = hdr[1] & 0x7F
    if length == 126:
        length = struct.unpack('>H', read_exact(conn, 2))[0]
    elif length == 127:
        length = struct.unpack('>Q', read_exact(conn, 8))[0]
    if masked:
        mask = read_exact(conn, 4)
        payload = read_exact(conn, length)
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    else:
        payload = read_exact(conn, length)
    return opcode, payload


def write_ws_frame(conn, opcode, payload=b''):
    header = bytes([0x80 | opcode])
    length = len(payload)
    if length < 126:
        header += bytes([length])
    elif length < 65536:
        header += bytes([126]) + struct.pack('>H', length)
    else:
        header += bytes([127]) + struct.pack('>Q', length)
    conn.sendall(header + payload)


def handle_client(conn, addr):
    try:
        conn.settimeout(120)
        # 握手
        data = b''
        while b'\r\n\r\n' not in data:
            chunk = conn.recv(1024)
            if not chunk:
                raise ConnectionError('closed before handshake')
            data += chunk
            if len(data) > 8192:
                raise ConnectionError('handshake too large')
        headers = data.decode('latin-1', 'ignore').split('\r\n')
        resp = ws_handshake(headers)
        conn.sendall(resp.encode('latin-1'))
        with clients_lock:
            clients.add(conn)
        logging.info(f'[WS] 连接: {addr[0]}:{addr[1]} (当前 {len(clients)})')
        # 保持连接：读帧（记录内容），响应 ping/pong
        while True:
            try:
                opcode, payload = read_ws_frame(conn)
                if opcode == 0x8:  # close
                    logging.info(f'[WS] 关闭: {addr[0]}')
                    break
                elif opcode == 0x9:  # ping
                    write_ws_frame(conn, 0xA, payload)  # pong
                else:
                    # 记录收到的消息（text=1, binary=2）
                    logging.info(f'[WS] 收到 opcode={opcode} len={len(payload)}: {payload[:200].hex()}')
                # 其他消息（text/binary）忽略
            except socket.timeout:
                # 空闲超时：发 ping 保活
                try:
                    write_ws_frame(conn, 0x9, b'')
                except Exception:
                    break
    except Exception as e:
        logging.debug(f'[WS] {addr[0]} 断开: {e}')
    finally:
        with clients_lock:
            clients.discard(conn)
        try:
            conn.close()
        except Exception:
            pass


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(128)
    logging.info(f'[WS] Player WebSocket 监听 {HOST}:{PORT} /account/ws (that-sky 方式, 空连接)')
    while True:
        conn, addr = srv.accept()
        t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
        t.start()


if __name__ == '__main__':
    main()
