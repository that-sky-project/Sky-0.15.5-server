# 启动脚本 - 容器启动时先安装依赖再运行
#!/bin/bash
pip install --no-cache-dir -r /app/requirements.txt
python /app/index.py
