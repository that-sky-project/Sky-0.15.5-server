# db.py - 统一数据库模块
# 支持 MySQL/MariaDB（推荐用于 1Panel）和 SQLite（兼容旧版）
# 在 config.json 中配置 use_mysql: true 即可切换到 MySQL

import json
import os
import sqlite3
import logging
import threading

logger = logging.getLogger(__name__)

# 线程本地存储，每个线程一个连接
_local = threading.local()

_db_config = {
    "use_mysql": False,
    "mysql_host": "127.0.0.1",
    "mysql_port": 3306,
    "mysql_user": "root",
    "mysql_password": "",
    "mysql_database": "wbsky",
    "mysql_charset": "utf8mb4",
    "sqlite_path": "",
}

_pymysql_available = False
try:
    import pymysql
    _pymysql_available = True
except ImportError:
    pass


def load_db_config():
    """从 config.json 加载数据库配置"""
    global _db_config
    try:
        config_path = os.path.join(os.path.dirname(__file__), "config.json")
        with open(config_path, encoding="utf-8") as f:
            cfg = json.load(f)

        _db_config["use_mysql"] = cfg.get("use_mysql", False)
        _db_config["mysql_host"] = cfg.get("mysql_host", "127.0.0.1")
        _db_config["mysql_port"] = cfg.get("mysql_port", 3306)
        _db_config["mysql_user"] = cfg.get("mysql_user", "root")
        _db_config["mysql_password"] = cfg.get("mysql_password", "")
        _db_config["mysql_database"] = cfg.get("mysql_database", "wbsky")
        _db_config["mysql_charset"] = cfg.get("mysql_charset", "utf8mb4")

        db_dir = os.path.join(os.path.dirname(__file__), "db")
        _db_config["sqlite_path"] = os.path.join(db_dir, "users.db")

        if _db_config["use_mysql"]:
            if not _pymysql_available:
                logger.warning("MySQL 已启用但 pymysql 未安装，将回退到 SQLite")
                logger.warning("请执行: pip install pymysql")
                _db_config["use_mysql"] = False
            else:
                logger.info(f"数据库模式: MySQL ({_db_config['mysql_user']}@{_db_config['mysql_host']}:{_db_config['mysql_port']}/{_db_config['mysql_database']})")
        else:
            logger.info(f"数据库模式: SQLite ({_db_config['sqlite_path']})")

    except Exception as e:
        logger.warning(f"加载数据库配置失败，使用默认 SQLite: {e}")
        _db_config["use_mysql"] = False


def _get_mysql_conn():
    """获取 MySQL 连接（线程本地）"""
    conn = getattr(_local, 'mysql_conn', None)
    if conn is None:
        try:
            conn = pymysql.connect(
                host=_db_config["mysql_host"],
                port=_db_config["mysql_port"],
                user=_db_config["mysql_user"],
                password=_db_config["mysql_password"],
                database=_db_config["mysql_database"],
                charset=_db_config["mysql_charset"],
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=False
            )
            _local.mysql_conn = conn
        except Exception as e:
            logger.error(f"MySQL 连接失败: {e}")
            raise
    else:
        # 检查连接是否存活
        try:
            conn.ping(reconnect=True)
        except Exception:
            try:
                conn.close()
            except Exception:
                pass
            conn = pymysql.connect(
                host=_db_config["mysql_host"],
                port=_db_config["mysql_port"],
                user=_db_config["mysql_user"],
                password=_db_config["mysql_password"],
                database=_db_config["mysql_database"],
                charset=_db_config["mysql_charset"],
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=False
            )
            _local.mysql_conn = conn
    return conn


def _get_sqlite_conn():
    """获取 SQLite 连接（线程本地）"""
    conn = getattr(_local, 'sqlite_conn', None)
    if conn is None:
        os.makedirs(os.path.dirname(_db_config["sqlite_path"]), exist_ok=True)
        conn = sqlite3.connect(_db_config["sqlite_path"])
        conn.row_factory = sqlite3.Row
        _local.sqlite_conn = conn
    return conn


def get_conn():
    """获取数据库连接（根据配置自动选择 MySQL 或 SQLite）"""
    if _db_config["use_mysql"]:
        return _get_mysql_conn()
    else:
        return _get_sqlite_conn()


def execute(sql, params=None):
    """
    执行 SQL 语句（INSERT/UPDATE/DELETE）
    返回受影响的行数
    """
    conn = get_conn()
    cursor = conn.cursor()
    try:
        if _db_config["use_mysql"]:
            # MySQL 使用 %s 占位符
            mysql_sql = sql.replace("?", "%s")
            cursor.execute(mysql_sql, params or ())
        else:
            cursor.execute(sql, params or ())
        conn.commit()
        return cursor.rowcount
    except Exception as e:
        conn.rollback()
        raise
    finally:
        cursor.close()


def query_one(sql, params=None):
    """
    查询单行数据
    返回 dict 或 None
    """
    conn = get_conn()
    cursor = conn.cursor()
    try:
        if _db_config["use_mysql"]:
            mysql_sql = sql.replace("?", "%s")
            cursor.execute(mysql_sql, params or ())
        else:
            cursor.execute(sql, params or ())
        row = cursor.fetchone()
        if row is None:
            return None
        # MySQL 返回 dict，SQLite 返回 Row 对象，统一转 dict
        if _db_config["use_mysql"]:
            return row
        else:
            return dict(row)
    finally:
        cursor.close()


def query_all(sql, params=None):
    """
    查询多行数据
    返回 list[dict]
    """
    conn = get_conn()
    cursor = conn.cursor()
    try:
        if _db_config["use_mysql"]:
            mysql_sql = sql.replace("?", "%s")
            cursor.execute(mysql_sql, params or ())
        else:
            cursor.execute(sql, params or ())
        rows = cursor.fetchall()
        if _db_config["use_mysql"]:
            return rows
        else:
            return [dict(row) for row in rows]
    finally:
        cursor.close()


def init_db():
    """初始化数据库表结构"""
    if _db_config["use_mysql"]:
        _init_mysql()
    else:
        _init_sqlite()
    _init_social_tables()


def _init_social_tables():
    """★ 2026-10-03 新增：社交链路（加好友邀请 + 礼物消息）。

    背景：客户端有一整套社交接口，我们以前**一个都没实现**，全被 catch-all 兜成 `{}`，
    所以「给蜡烛后对方看不到接受按钮」。表结构只用 VARCHAR/BIGINT/INT ——
    MySQL 与 SQLite 都能建（TEXT 不能做 PRIMARY KEY / 不能有默认值）。
    """
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pending_invites (
            token_id   VARCHAR(64) PRIMARY KEY,
            from_user  VARCHAR(64) NOT NULL,
            to_user    VARCHAR(64) NOT NULL,
            nickname   VARCHAR(191) DEFAULT '',
            level_id   BIGINT DEFAULT 0,
            created_at BIGINT DEFAULT 0,
            status     VARCHAR(16) DEFAULT 'pending'
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS gift_messages (
            msg_id         VARCHAR(64) PRIMARY KEY,
            from_user      VARCHAR(64) NOT NULL,
            to_user        VARCHAR(64) NOT NULL,
            gift_type      INT DEFAULT 0,
            currency_type  INT DEFAULT 0,
            currency_count INT DEFAULT 0,
            raw_message    VARCHAR(255) DEFAULT '',
            sent_at        BIGINT DEFAULT 0,
            claimed        INT DEFAULT 0
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS friends (
            user_id    VARCHAR(64) NOT NULL,
            friend_id  VARCHAR(64) NOT NULL,
            nickname   VARCHAR(191) DEFAULT '',
            level      INT DEFAULT 0,
            created_at BIGINT DEFAULT 0
        )
    ''')
    conn.commit()
    try:
        cursor.close()
    except Exception:
        pass


def query_all(sql, params=None):
    """查询多行，返回 list[dict]。"""
    conn = get_conn()
    cursor = conn.cursor()
    try:
        if _db_config["use_mysql"]:
            cursor.execute(sql.replace("?", "%s"), params or ())
        else:
            cursor.execute(sql, params or ())
        rows = cursor.fetchall()
        out = []
        for r in rows:
            out.append(r if _db_config["use_mysql"] else dict(r))
        return out
    finally:
        try:
            cursor.close()
        except Exception:
            pass


def _init_sqlite():
    """初始化 SQLite 数据库表"""
    conn = _get_sqlite_conn()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id         TEXT PRIMARY KEY,
            device_id  TEXT NOT NULL,
            recovery   TEXT NOT NULL,
            achievements   TEXT DEFAULT NULL,
            candles    INTEGER NOT NULL DEFAULT 3,
            unlocks    TEXT DEFAULT NULL,
            collects   TEXT DEFAULT NULL,
            wing_buffs TEXT DEFAULT NULL,
            checkpoint INTEGER DEFAULT NULL,
            visited_home INTEGER DEFAULT 0,
            outfit_wing   INTEGER DEFAULT 0,
            outfit_prop   INTEGER DEFAULT 0,
            outfit_face   INTEGER DEFAULT 0,
            outfit_mask   INTEGER DEFAULT 0,
            outfit_hair   INTEGER DEFAULT 0,
            outfit_body   INTEGER DEFAULT 0,
            outfit_arms   INTEGER DEFAULT 0,
            outfit_feet   INTEGER DEFAULT 0,
            outfit_hat    INTEGER DEFAULT 0,
            outfit_horn   INTEGER DEFAULT 0,
            outfit_neck   INTEGER DEFAULT 0,
            outfit_height REAL DEFAULT 0,
            purchase  TEXT DEFAULT NULL,
            user_data TEXT DEFAULT NULL
        )
    ''')
    conn.commit()
    # 迁移：老库补 visited_home 列（记录账号是否到过遇境 CandleSpace）
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "visited_home" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN visited_home INTEGER DEFAULT 0")
        conn.commit()
    # 卡密表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS license_keys (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            key_code     TEXT NOT NULL UNIQUE,
            note         TEXT DEFAULT '',
            duration_h   INTEGER NOT NULL DEFAULT 0,
            created_at   INTEGER NOT NULL DEFAULT 0,
            activated_at INTEGER NOT NULL DEFAULT 0,
            expire_at    INTEGER NOT NULL DEFAULT 0,
            device_id    TEXT DEFAULT '',
            last_ip      TEXT DEFAULT '',
            last_seen    INTEGER NOT NULL DEFAULT 0,
            use_count    INTEGER NOT NULL DEFAULT 0,
            status       TEXT DEFAULT 'unused'
        )
    ''')
    conn.commit()
    cursor.close()


def _init_mysql():
    """初始化 MySQL 数据库表"""
    conn = _get_mysql_conn()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(64) PRIMARY KEY,
            device_id VARCHAR(64) NOT NULL,
            recovery VARCHAR(128) NOT NULL,
            achievements TEXT DEFAULT NULL,
            candles INT NOT NULL DEFAULT 3,
            unlocks TEXT DEFAULT NULL,
            collects TEXT DEFAULT NULL,
            wing_buffs TEXT DEFAULT NULL,
            checkpoint BIGINT DEFAULT NULL,
            visited_home INT DEFAULT 0,
            outfit_wing BIGINT DEFAULT 0,
            outfit_prop BIGINT DEFAULT 0,
            outfit_face BIGINT DEFAULT 0,
            outfit_mask BIGINT DEFAULT 0,
            outfit_hair BIGINT DEFAULT 0,
            outfit_body BIGINT DEFAULT 0,
            outfit_arms BIGINT DEFAULT 0,
            outfit_feet BIGINT DEFAULT 0,
            outfit_hat BIGINT DEFAULT 0,
            outfit_horn BIGINT DEFAULT 0,
            outfit_neck BIGINT DEFAULT 0,
            outfit_height FLOAT DEFAULT 0,
            purchase TEXT DEFAULT NULL,
            user_data TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_device_id (device_id),
            INDEX idx_checkpoint (checkpoint)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')
    conn.commit()
    # 迁移：老库补 visited_home 列
    row = query_one("SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS "
                    "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'visited_home'")
    if not row or row.get("cnt") == 0:
        cursor.execute("ALTER TABLE users ADD COLUMN visited_home INT DEFAULT 0")
        conn.commit()

    # 卡密表（鼓启私服 卡密系统）
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS license_keys (
            id INT AUTO_INCREMENT PRIMARY KEY,
            key_code VARCHAR(64) NOT NULL UNIQUE,
            note VARCHAR(191) DEFAULT '',
            duration_h INT NOT NULL DEFAULT 0,
            created_at BIGINT NOT NULL DEFAULT 0,
            activated_at BIGINT NOT NULL DEFAULT 0,
            expire_at BIGINT NOT NULL DEFAULT 0,
            device_id VARCHAR(64) DEFAULT '',
            last_ip VARCHAR(64) DEFAULT '',
            last_seen BIGINT NOT NULL DEFAULT 0,
            use_count INT NOT NULL DEFAULT 0,
            status VARCHAR(16) DEFAULT 'unused',
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')
    conn.commit()
    cursor.close()


def user_exists(user_id):
    """检查用户是否存在"""
    row = query_one("SELECT 1 FROM users WHERE id = ?", (user_id,))
    return row is not None


def create_user(user_id, device_id, recovery):
    """创建新用户"""
    execute(
        "INSERT INTO users(id, device_id, recovery) VALUES (?, ?, ?)",
        (user_id, device_id, recovery)
    )


def get_user_field(user_id, field):
    """获取用户单个字段"""
    row = query_one(f"SELECT {field} FROM users WHERE id = ?", (user_id,))
    if row is None:
        return None
    return row.get(field)


def set_user_field(user_id, field, value):
    """设置用户单个字段"""
    return execute(f"UPDATE users SET {field} = ? WHERE id = ?", (value, user_id))


# 模块加载时自动初始化配置
load_db_config()
