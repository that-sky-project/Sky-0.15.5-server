# route/account.py
import json
import os
import sys
import uuid
import secrets
import tempfile
import threading
import time
import glob
from datetime import datetime
from flask import Blueprint, request, jsonify, send_from_directory, current_app

# 导入统一数据库模块（支持 MySQL 和 SQLite）
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import db as database

account_bp = Blueprint('account', __name__, url_prefix='/account')

# ---------- 工具函数（必须放在所有路由函数之前） ----------
def load_config():
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
    with open(config_path, encoding="utf-8") as f:
        return json.load(f)


def _merge_reported_unlocks(user_id, payload, list_key):
    """把该账号在库里已上报过的解锁项合并进 all_unlock*.json 的返回结果。

    ★ 重要修复（2026-10-01）：客户端推进剧情靠的是解锁名（unlock name），
      只要有一项在服务端返回里**不存在**，客户端上报后永远收不到确认，
      就会卡死在那个动作上，而且**重启游戏也没用**（配置里根本没有这一项）。

      真实案例：客户端在晨岛/遇境枢纽的神殿冥想点「坐下」时会走
      `HubStatueForm`（7 大区雕像形态之一），但 all_unlock.json 里当时只有
      Day/Rain/Sunset/Dusk/Night/Storm 六个 StatueForm，**唯独漏了
      HubStatueForm** → 玩家坐下后不传送、一直卡在加载/过场。
      客户端其实已经把 HubStatueForm 上报进库了（见 users.unlocks），
      只是回包时被这张静态配置表盖掉了。

      这里做兜底：凡是客户端自己上报过的解锁名，一律并回返回列表并置
      ack=true 回执 —— 以后配置再漏项也能自愈，不用再逐个补 JSON。
    """
    if not user_id:
        return payload
    try:
        raw = database.get_user_field(user_id, "unlocks")
    except Exception:
        return payload
    if not raw:
        return payload
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "ignore")
    try:
        reported = json.loads(raw) or []
    except (TypeError, ValueError):
        return payload

    items = payload.get(list_key) or []
    have = {u.get("name") for u in items if isinstance(u, dict)}
    for it in reported:
        if not isinstance(it, dict):
            continue
        name = it.get("name")
        if not name or name in have:
            continue
        have.add(name)
        entry = {
            "name": name,
            "type": it.get("type", "level"),
            "ack": True,
            "unlocked_at": it.get("unlocked_at", 0),
        }
        if "cost" in it:
            entry["cost"] = it["cost"]
        items.append(entry)
    payload[list_key] = items
    return payload


def _login_user_ok(user, device):
    """登录放行判定。

    ★ 重要修复（2026-10-01）：
      客户端本地会持久化自己的账号 id（files/AccountAuthInfo.bin）。
      一旦服务端换机 / 换库 / 清库（本项目就发生过：账号建在旧库上），
      登录就会 404 user not found → 客户端弹「服务器错误 / 账号验证失败」，
      并且**后续所有登录资源同步全部跳过**（日志里看不到 Syncing login resource）。
      这里改成：账号不存在就按客户端给的 id 直接补建一条，自愈。
      想恢复旧行为，在 config.json 里设 "auto_create_user_on_login": false。
    """
    if not user:
        return False
    if database.user_exists(user):
        return True

    try:
        auto = load_config().get("auto_create_user_on_login", True)
    except Exception:
        auto = True
    if not auto:
        return False

    try:
        database.create_user(user, device or str(uuid.uuid4()), secrets.token_hex(32))
        print("[login] auto-created missing user %s (device=%s)" % (user, device), flush=True)
        return True
    except Exception as e:
        print("[login] auto-create failed for %s: %r" % (user, e), flush=True)
        try:
            return database.user_exists(user)
        except Exception:
            return False

# ---------- 数据库初始化 ----------
# 使用统一的 db 模块，支持 MySQL/SQLite 自动切换
database.init_db()

# ============================================================
# 账户相关路由
# ============================================================

@account_bp.route("/get_latest_build_version", methods=["POST"])
def get_latest_build_version():
    cfg = load_config()
    return jsonify(
        {
            "latest_build_version": cfg["latest_build_version"],
            "min_gpu_rating": 270,
            "maintenance_mode": False,
            "maintenance_msg": "",
            "app_store_uri": cfg["app_store_uri"],
            "tos": {
                "tos_url": cfg["tos_url"],
                "pp_url": cfg["pp_url"],
                "version": "4"
            },
            "cs_enabled": True,
            "cs_db_enabled": False,
            "country_code": "CN"
        }
    )

@account_bp.route("/get_vars", methods=["POST"])
def get_vars():
    vars_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "vars.json")
    with open(vars_path, encoding="utf-8") as f:
        data = json.load(f)
    if "vars" not in data:
        data["vars"] = {}
    data["vars"]["welcome"] = str(uuid.uuid4())
    return jsonify(data)

@account_bp.route("/get_motd", methods=["POST"])
def get_motd():
    cfg = load_config()
    current_timestamp = int(time.time())
    # ★ 公告从 config/motd.json 读取，改公告直接编辑该文件，无需改代码
    motd_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "motd.json")
    try:
        with open(motd_path, encoding="utf-8-sig") as _f:
            motd_data = json.load(_f)
    except Exception:
        motd_data = {}
    return jsonify({
        "motd_title": motd_data.get("motd_title", "wbSky"),
        "motd": motd_data.get("motd", "欢迎来到 wbSky 私服。"),
        "motd_timestamp": current_timestamp,
        "motd_version": motd_data.get("motd_version", 137688),
        "motd_buttons": motd_data.get("motd_buttons", []),
        "motd_season_end": motd_data.get("motd_season_end", 3408191999)
    })

@account_bp.route("/auth/login", methods=["POST"])
def new_login():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    device = req.get("device")

    if not user or not device:
        return jsonify({"error": "missing user or device"}), 400

    if not _login_user_ok(user, device):
        return jsonify({"error": "user not found"}), 404

    return jsonify({
        "authinfo":{
        "user": user,
        "device": device,
        "recovery_token": "",
        "key": "0000000000000000000000000000000000000000000000000000430079000000"
        },
        "session": secrets.token_hex(16),
        "resource_list": [
            "device_capabilities", "userdata", "set_friends", "set_friend_status",
            "online_friends", "set_random", "currency", "forge_rates", "motd",
            "outfit_defs", "achievements", "achievement_stats", "relationship_defs",
            "external_links", "event_schedule", "set_world_quests", "iap_list",
            "invite_list", "unlocks", "get_shop", "spirit_shops", "collectibles",
            "wing_buffs", "gift_messages", "set_app_badge_number",
            "messages", "chat", "infractions", "get_buff_defs", "event_currency_defs",
            "get_lootboxes", "checkpoints", "generic_shop_defs",
            "external_account_friends", "serendipity_matches", "get_star_tag_defs",
            "status_unlocks", "free_gifts", "get_map_defs", "achievement_defs",
            "achievement_stats_tracking"
        ],
        "external_links": [],
        "player_badge_type": -1
    })

@account_bp.route("/auth/create", methods=["POST"])
def new_create():
    user_id = str(uuid.uuid4())
    device_id = str(uuid.uuid4())
    session = secrets.token_hex(16)
    recovery = secrets.token_hex(32)
    database.create_user(user_id, device_id, recovery)

    return jsonify({
        "authinfo":{
        "user": user_id,
        "device": device_id,
        "key": "no_bcrypt",
        "recovery_token": recovery
        },
        "session": session,
        "resource_list": [
            "device_capabilities", "userdata", "set_friends", "set_friend_status",
            "online_friends", "set_random", "currency", "forge_rates", "motd",
            "outfit_defs", "achievements", "achievement_stats", "relationship_defs",
            "external_links", "event_schedule", "set_world_quests", "iap_list",
            "invite_list", "unlocks", "get_shop", "spirit_shops", "collectibles",
            "wing_buffs", "gift_messages", "set_app_badge_number",
            "messages", "chat", "infractions", "get_buff_defs", "event_currency_defs",
            "get_lootboxes", "checkpoints", "generic_shop_defs",
            "external_account_friends", "serendipity_matches", "get_star_tag_defs",
            "status_unlocks", "free_gifts", "get_map_defs", "achievement_defs",
            "achievement_stats_tracking"
        ]
    })

@account_bp.route("/login", methods=["POST"])
def auth_login():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    device = req.get("device")
    current_timestamp = int(time.time())

    if not user or not device:
        return jsonify({"error": "missing user or device"}), 400

    if not _login_user_ok(user, device):
        return jsonify({"error": "user not found"}), 404

    return jsonify({
        "user": user,
        "device": device,
        "key": "0000000000000000000000000000000000000000000000000000430079000000",
        "session": secrets.token_hex(16),
        "resource_list": [
            "device_capabilities", "userdata", "set_friends", "set_friend_status",
            "online_friends", "set_random", "currency", "forge_rates", "motd",
            "outfit_defs", "achievements", "achievement_stats", "relationship_defs",
            "external_links", "event_schedule", "set_world_quests", "iap_list",
            "invite_list", "unlocks", "get_shop", "spirit_shops", "collectibles",
            "wing_buffs", "gift_messages", "set_app_badge_number",
            "messages", "chat", "infractions", "get_buff_defs", "event_currency_defs",
            "get_lootboxes", "checkpoints", "generic_shop_defs",
            "external_account_friends", "serendipity_matches", "get_star_tag_defs",
            "status_unlocks", "free_gifts", "get_map_defs", "achievement_defs",
            "achievement_stats_tracking"
        ],
        "external_links": [],
        "player_badge_type": -1,
        "motd_title": "你知道吗？",
        "motd": "在遇境的天上，有许多星星。这些星星来自先灵或你的友人，点亮他们吧！",
        "motd_timestamp": current_timestamp,
        "motd_version": 137688,
        "motd_buttons": [],
        "motd_season_end": 3408191999
    })

@account_bp.route("/create", methods=["POST"])
def auth_create():
    user_id = str(uuid.uuid4())
    device_id = str(uuid.uuid4())
    session = secrets.token_hex(16)
    recovery = secrets.token_hex(32)
    current_timestamp = int(time.time())

    database.create_user(user_id, device_id, recovery)

    return jsonify({
        "user": user_id,
        "device": device_id,
        "key": "no_bcrypt",
        "recovery_token": recovery,
        "session": session,
        "resource_list": [
            "device_capabilities", "userdata", "set_friends", "set_friend_status",
            "online_friends", "set_random", "currency", "forge_rates", "motd",
            "outfit_defs", "achievements", "achievement_stats", "relationship_defs",
            "external_links", "event_schedule", "set_world_quests", "iap_list",
            "invite_list", "unlocks", "get_shop", "spirit_shops", "collectibles",
            "wing_buffs", "gift_messages", "set_app_badge_number",
            "messages", "chat", "infractions", "get_buff_defs", "event_currency_defs",
            "get_lootboxes", "checkpoints", "generic_shop_defs",
            "external_account_friends", "serendipity_matches", "get_star_tag_defs",
            "status_unlocks", "free_gifts", "get_map_defs", "achievement_defs",
            "achievement_stats_tracking"
        ],
        "motd_title": "你知道吗？",
        "motd": "在遇境的天上，有许多星星。这些星星来自先灵或你的友人，点亮他们吧！",
        "motd_timestamp": current_timestamp,
        "motd_version": 137688,
        "motd_buttons": [],
        "motd_season_end": 3408191999
    })

@account_bp.route("/support/has_reply", methods=["POST"])
def has_reply():
    cfg = load_config()
    return jsonify({
        "result": "ok",
        "has_reply": cfg["has_reply"]
    })

@account_bp.route("/device_capabilities/lookup", methods=["POST"])
def device_capabilities_lookup():
    cfg = load_config()
    return jsonify({
        "device_capabilities": {
            "gpu_rating": cfg["gpu_rating"],
            "hash_id": cfg["hash_id"]
        }
    })

@account_bp.route("/sync_user_data", methods=["POST"])
def syncserdata():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    if not user:
        return jsonify({"error": "Missing 'user' field"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "Can't find user"}), 400

    # 读取已保存的 user_data
    stored_data = database.get_user_field(user, "user_data")

    # 如果客户端上传了数据，则保存
    if req.get("data"):
        data_str = json.dumps({
            "time": req.get("time"),
            "version": req.get("version"),
            "data": req.get("data")
        }, ensure_ascii=False)
        database.set_user_field(user, "user_data", data_str)

    # 返回已保存的数据（如果有），否则回传客户端上传的数据
    if stored_data:
        try:
            parsed = json.loads(stored_data)
            return jsonify({"userdata": parsed})
        except (json.JSONDecodeError, TypeError):
            pass

    return jsonify({
        "userdata": {
            "time": req.get("time", 0),
            "version": req.get("version", 0),
            "data": req.get("data", {})
        }
    })

@account_bp.route("/userdata", methods=["POST"])
def userdata():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    if not user:
        return jsonify({"error": "Missing 'user' field"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "Can't find user"}), 400

    stored_data = database.get_user_field(user, "user_data")

    # 如果客户端上传了数据，则保存
    if req.get("data"):
        data_str = json.dumps({
            "time": req.get("time"),
            "version": req.get("version"),
            "data": req.get("data")
        }, ensure_ascii=False)
        database.set_user_field(user, "user_data", data_str)

    # 返回已保存的数据（如果有）
    if stored_data:
        try:
            parsed = json.loads(stored_data)
            return jsonify({"userdata": parsed})
        except (json.JSONDecodeError, TypeError):
            pass

    return jsonify({
        "userdata": {
            "time": req.get("time", 0),
            "version": req.get("version", 0),
            "data": req.get("data", {})
        }
    })

@account_bp.route("/get_friends", methods=["POST"])
def get_friends():
    """好友列表。

    ★ 2026-10-03：原来返回的是**写死的假好友**（固定那个 41f54dba-… 的 UUID），
      既和真实账号无关，也不带昵称/关系等级。现在改成读 friends 表
      （接受邀请时写入），返回结构保持原来的 `set_friends: [{update_friends, AccountFriend}]`
      形状不变（形状不对会让客户端解析失败），只是内容换成真好友。
    """
    req = request.get_json(force=True, silent=True) or {}
    me = _req_user(req)
    rows = []
    if me:
        try:
            rows = database.query_all(
                "SELECT friend_id, nickname, level FROM friends WHERE user_id = ? "
                "ORDER BY created_at ASC LIMIT 200", (me,))
        except Exception as e:
            _social_log("get_friends.err", repr(e))
    items = []
    for idx, r in enumerate(rows or []):
        fid = r.get("friend_id")
        if not fid:
            continue
        ts = int(r.get("created_at") or 0) or (idx + 1)
        items.append({
            "update_friends": True,
            "AccountFriend": fid,
            "friend_id": fid,
            "friend": fid,
            "nickname": r.get("nickname", "") or "",
            "level": r.get("level", 0) or 0,
            "friend_level": r.get("level", 0) or 0,
            # ★★★ 客户端 AccountFriend barn 的硬性要求（libBootloader.so 字符串簇）：
            #     m_friendUpdateTime should be in sync with m_friends and any index
            #     in m_friends must be present in m_friendUpdateTime
            #     updateTimeIdx != kAccount_FriendMaxCount
            #     m_friendCount == kAccount_FriendMaxCount
            #   ⇒ **每个好友必须带 friendUpdateTime**（客户端拿它建"更新索引"表）。
            #   缺了它，客户端建不出索引 → 好友被当成"没同步"，关系也不生效
            #   （表现就是「给蜡烛后一直被退回」）。这里用 created_at 当时间戳。
            "friendUpdateTime": ts,
            "updateTime": ts,
        })
    return jsonify({
        "set_friends": items,
        "friend_count": len(items),
        "set_friend_count": len(items),
        # ⚠️ 千万不要加 `update_friend_commerce`！
        #   我上一版加了 `"update_friend_commerce": []`（列表），真机立刻报：
        #     W Account: Failed to parse resource sync response of AccountFriendBarn
        #                for syncAction update_friend_commerce
        #   ⇒ 它不是一个列表（多半是按好友索引的对象/映射），形状不对会让整个
        #     AccountFriendBarn 的这次同步报解析失败。**不发给它就不会出错**
        #     （缺键 = 没有 commerce 更新，客户端会跳过）。
    })

def _friend_entry(user_id, fid):
    """构造一条客户端认的 AccountFriend 条目（含 friendUpdateTime）。"""
    nick = ""
    ts = 0
    try:
        row = database.query_one(
            "SELECT nickname, created_at FROM friends WHERE user_id = ? AND friend_id = ?",
            (user_id, fid))
        if row:
            nick = row.get("nickname") or ""
            ts = int(row.get("created_at") or 0)
    except Exception as e:
        _social_log("friend_entry.err", repr(e))
    return {
        "update_friends": True,
        "AccountFriend": fid, "friend_id": fid, "friend": fid,
        "nickname": nick, "level": 0, "friend_level": 0,
        "friendUpdateTime": ts or 1, "updateTime": ts or 1,
    }


def _friend_pair(req):
    """从请求里取 (我, 对方)。字段名在客户端串表里是 /friend /target /recv_user。"""
    me = _req_user(req)
    fid = _pick_any(req, "friend", "target", "recv_user", "friend_id", "user_id")
    return me, (str(fid).strip() if fid else "")


@account_bp.route("/set_friend_name", methods=["POST"])
def set_friend_name():
    """给好友改昵称 —— 游戏里对方头顶那个「铅笔」按钮点的就是它。

    ★ 客户端字段（libBootloader.so 字符串簇）：`/friend` + `/name`。
      URL 串紧跟在 `AccountMessageType` 那一片里：
        /name | /account/drop_unlock | /friend | /account/set_friend_name |
        /account/set_friend_favorite | /blocked | /account/set_friend_block |
        /mute | /account/set_friend_mute | /warp_blocked | /account/set_friend_warp_blocked |
        /hint | /account/remove_relationship_hint
      之前这些路由**全都没实现** → 被 catch-all 兜成 `{}` → 铅笔点了没有任何反应。
    """
    req = request.get_json(force=True, silent=True) or {}
    _social_log("set_friend_name.req", req)
    me, fid = _friend_pair(req)
    name = _pick_any(req, "name", "nickname", "friend_name")
    name = ("" if name is None else str(name))[:190]
    if not me or not fid:
        return jsonify({"error": "missing user or friend"}), 400
    try:
        if not database.query_one(
                "SELECT user_id FROM friends WHERE user_id = ? AND friend_id = ?", (me, fid)):
            database.execute(
                "INSERT INTO friends (user_id, friend_id, nickname, level, created_at) "
                "VALUES (?,?,?,?,?)", (me, fid, name, 0, _now()))
        else:
            database.execute(
                "UPDATE friends SET nickname = ? WHERE user_id = ? AND friend_id = ?",
                (name, me, fid))
    except Exception as e:
        _social_log("set_friend_name.err", repr(e))
    entry = _friend_entry(me, fid)
    resp = {"result": "ok", "status": "ok", "ok": True,
            "set_friends": [entry], "friend": fid, "name": name, "nickname": name}
    _social_log("set_friend_name.resp", {"user": me, "friend": fid, "name": name})
    return jsonify(resp)


def _friend_flag_route(flag):
    """set_friend_favorite / block / mute / warp_blocked —— 都是开关，回包让 UI 生效即可。"""
    req = request.get_json(force=True, silent=True) or {}
    me, fid = _friend_pair(req)
    value = _pick_any(req, flag, "value", "enabled", "on")
    _social_log("set_friend_%s" % flag, {"user": me, "friend": fid, "value": value})
    if not me or not fid:
        return jsonify({"error": "missing user or friend"}), 400
    entry = _friend_entry(me, fid)
    return jsonify({"result": "ok", "status": "ok", "ok": True, flag: bool(value),
                    "set_friends": [entry], "friend": fid})


@account_bp.route("/set_friend_favorite", methods=["POST"])
def set_friend_favorite():
    return _friend_flag_route("favorite")


@account_bp.route("/set_friend_block", methods=["POST"])
def set_friend_block():
    return _friend_flag_route("blocked")


@account_bp.route("/set_friend_mute", methods=["POST"])
def set_friend_mute():
    return _friend_flag_route("mute")


@account_bp.route("/set_friend_warp_blocked", methods=["POST"])
def set_friend_warp_blocked():
    return _friend_flag_route("warp_blocked")


@account_bp.route("/remove_relationship_hint", methods=["POST"])
def remove_relationship_hint():
    """清掉头顶那个「关系提示」图标（铅笔/蜡烛气泡）。

    客户端字段：`/hint`。之前没实现 → 提示消不掉，一直挂在对方头顶。
    """
    req = request.get_json(force=True, silent=True) or {}
    _social_log("remove_relationship_hint", req)
    me, fid = _friend_pair(req)
    hint = _pick_any(req, "hint", "hint_name", "name") or ""
    return jsonify({"result": "ok", "status": "ok", "ok": True,
                    "friend": fid, "hint": str(hint)})


@account_bp.route("/commerce/friend_info", methods=["POST"])
def commerce_friend_info():
    """好友商店/交易信息（客户端 AccountFriendCommerceInfoRequest → /account/commerce/friend_info）。"""
    req = request.get_json(force=True, silent=True) or {}
    me, fid = _friend_pair(req)
    return jsonify({"result": "ok", "status": "ok", "ok": True,
                    "friend": fid, "friend_info": {}, "commerce": [],
                    "set_friend_commerce": [], "update_friend_commerce": []})


@account_bp.route("/get_friend_statues", methods=["POST"])
def get_friend_statues():
    """好友星座雕像。客户端字段（.so 字符串簇）：set_friend_statues /
    update_friend_statues / sort_ver。原来是 `{}` → 客户端每次 resync 都空转。"""
    return jsonify({"set_friend_statues": [], "update_friend_statues": [],
                    "friend_statues": [], "sort_ver": 0})

@account_bp.route("/get_online_friends", methods=["POST"])
def get_friends_statues():
    """在线好友。客户端字段：update_online_friends / refresh_online_friends。"""
    return jsonify({"online_friends": [], "update_online_friends": [],
                    "refresh_online_friends": [], "set_online_friends": []})

@account_bp.route("/get_blocked_friends", methods=["POST"])
def get_blocked_friends():
    """拉黑列表。客户端字段：set_blocked_friends / page_next / page_prev。"""
    return jsonify({"set_blocked_friends": [], "blocked_friends": [],
                    "page_next": 0, "page_prev": 0})

@account_bp.route("/get_currency", methods=["POST"])
def get_currency():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")

    if not user:
        return jsonify({"error": "Cannot find Data"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "Cannot find Data"}), 404

    cfg = load_config()

    # ★ 修复「蜡烛数量永远不变」：
    #   原实现只在账号第一次出现时写入 3 根，之后**全服没有任何**增加蜡烛的写入点
    #   （私服没有实现「收集烛光 -> 换算蜡烛」的逻辑），所以蜡烛永远停在 3。
    #   现在支持 config.json 的 `all_user_candles`：每次拉取时把蜡烛**补齐**到该值。
    #   只补不降 —— 用聊天命令 `/cmd candles N` 加到更多时不会被覆盖回去。
    candles = database.get_user_field(user, "candles")
    try:
        candles = int(candles) if candles is not None else 0
    except (TypeError, ValueError):
        candles = 0

    # ★ 面板「设置」里按玩家指定的蜡烛数：直接覆盖（可升可降，滑条用）
    pc = _int_or_none(_get_prefs(user).get("candles"))
    if pc is not None:
        candles = max(0, pc)
        database.set_user_field(user, "candles", candles)
        return jsonify({"currency": {"candles": candles}})

    floor = cfg.get("all_user_candles")
    if floor is not None:
        try:
            floor = int(floor)
        except (TypeError, ValueError):
            floor = None

    if floor is not None:
        if candles < floor:
            candles = floor
            database.set_user_field(user, "candles", candles)
    elif candles == 0:
        candles = 3
        database.set_user_field(user, "candles", candles)

    return jsonify({"currency": {"candles": candles}})

@account_bp.route("/get_forge_rates", methods=["POST"])
def get_forge_rates():
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='forge_rates.json',
        mimetype='application/json'
    )

@account_bp.route("/get_achievements", methods=["POST"])
def get_achievements():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")

    if not user:
        return jsonify({"achievements": []}), 200

    achievements = database.get_user_field(user, "achievements")
    if achievements:
        return jsonify({"achievements": json.loads(achievements)})
    else:
        return jsonify({"achievements": []}), 200

@account_bp.route("/get_achievement_stats", methods=["POST"])
def get_achievement_stats():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")

    if not user:
        return jsonify({"achievement_stats": []}), 200

    raw_data = database.get_user_field(user, "achievements")
    raw = json.loads(raw_data) if raw_data else []
    stats = [
        {
            "type": item.get("type", ""),
            "value": item.get("value", 0),
            "update": item.get("update", 0)
        }
        for item in raw
    ]
    return jsonify({"achievement_stats": stats})

@account_bp.route("/get_surveys", methods=["POST"])
def get_surveys():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='surveys.json',
        mimetype='application/json'
    )

@account_bp.route("/get_event_schedule", methods=["POST"])
def get_event_schedule():
    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "event_schedule.json")
    if not os.path.isfile(cfg_path):
        return jsonify({"error": "config not found"}), 404

    with open(cfg_path, encoding="utf-8") as f:
        data = json.load(f)

    if "event_schedule" in data:
        data["event_schedule"]["server_time"] = int(time.time())
    else:
        data["event_schedule"] = {"server_time": int(time.time())}

    return jsonify(data)

@account_bp.route("/get_account_world_quests", methods=["POST"])
def get_account_world_quests():
    cfg = load_config()
    return jsonify({"set_wrld_quests": []})

@account_bp.route("/get_unlocks", methods=["POST"])
def get_unlocks():
    cfg = load_config()

    if cfg.get("all_users_allunlock", False):
        # ★ 全解锁，但首次账号（未到过遇境）剔除"遇境到达"标记，
        #   否则客户端永远认为已到过遇境，无视 checkpoint 直接出生遇境
        req = request.get_json(force=True, silent=True) or {}
        user_id = req.get("user")
        first_time = False
        if user_id:
            try:
                first_time = not int(database.get_user_field(user_id, "visited_home") or 0)
            except Exception:
                first_time = False
        base_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")
        with open(os.path.join(base_dir, "all_unlock.json"), encoding="utf-8-sig") as _f:
            payload = json.load(_f)
        if first_time:
            forbid = {"first_loaded_CandleSpace", "first_loaded_SkyHub2", "SkyHubFirstArrival",
                      "first_loaded_HubReveal", "1stHub", "DayHub", "FinishedIntro"}
            payload["unlocks"] = [u for u in payload.get("unlocks", []) if u.get("name") not in forbid]
        # ★ 兜底：客户端自己上报过的解锁项一律并回（修「神殿坐下不传送」的根因）
        payload = _merge_reported_unlocks(user_id, payload, "unlocks")
        return jsonify(payload)

    req = request.get_json(force=True, silent=True) or {}
    user_id = req.get("user")
    if not user_id:
        return jsonify({"error": "No user_id provided"}), 400

    if not database.user_exists(user_id):
        return jsonify({"error": "Cannot find latest checkpoint"}), 404

    raw_data = database.get_user_field(user_id, "unlocks")
    data = json.loads(raw_data) if raw_data else []

    unlocks = [
        {
            "name": item.get("name", ""),
            "type": "level",
            "ack": item.get("ack", False),
            "unlocked_at": item.get("unlocked_at", 0)
        }
        for item in data
    ]
    return jsonify({"unlocks": unlocks})

@account_bp.route("/get_shop", methods=["POST"])
def get_shop():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='get_shop.json',
        mimetype='application/json'
    )

@account_bp.route("/get_spirit_shops", methods=["POST"])
def get_spirit_shops():
    req = request.get_json(force=True, silent=True) or {}
    try:
        offset = int(req.get("o", 0) or 0)
        limit = int(req.get("l", 0) or 0)
    except (TypeError, ValueError):
        offset, limit = 0, 0
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'spirit_shops.json')
    try:
        with open(path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
    except Exception:
        data = {"spirit_shops": [], "spirit_shops_version": 0, "spirit_shops_total_count": 0}
    items = data.get("spirit_shops", [])
    total = len(items)
    if limit > 0:
        items = items[offset:offset + limit]
    else:
        items = []
    return jsonify({
        "spirit_shops": items,
        "spirit_shops_total_count": total,
        "spirit_shops_version": data.get("spirit_shops_version", 0)
    })

@account_bp.route("/get_collectibles", methods=["POST"])
def get_collectibles():
    cfg = load_config()
    if cfg.get("all_user_allcollects", False):
        return send_from_directory(
            directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), "config"),
            path='all_collect.json',
            mimetype='application/json'
        )

    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    if not user:
        return jsonify({"error": "No The User"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "No The User"}), 404

    raw_data = database.get_user_field(user, "collects")
    data = json.loads(raw_data) if raw_data else []

    if not data:
        default = ["skykid", "sit", "normal", "flame", "home", "cape"]
        database.set_user_field(user, "collects", json.dumps(default))
        data = default

    achievements = [
        {
            "id": cid,
            "used": True,
            "candle_space": False,
            "carrying": False,
            "level": 2,
            "permanent_level": 1
        }
        for cid in data
    ]
    return jsonify({"collectibles": achievements})

@account_bp.route("/wing_buffs/get", methods=["POST"])
def get_wing_buffs():
    cfg = load_config()
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")

    # ★ 面板「设置」里指定的光翼数量：从全量列表里取前 N 个下发（滑条用）
    n = _int_or_none(_get_prefs(user).get("wingbuffs")) if user else None

    cfg_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")
    if cfg.get("all_user_allhaswingbuff", False):
        if n is None:
            return send_from_directory(directory=cfg_dir,
                                       path='all_wing_buffs.json',
                                       mimetype='application/json')
        try:
            with open(os.path.join(cfg_dir, "all_wing_buffs.json"),
                      encoding="utf-8") as f:
                d = json.load(f)
            wbs = d.get("wing_buffs") or []
            d["wing_buffs"] = wbs[:max(0, n)]
            return jsonify(d)
        except Exception:
            return send_from_directory(directory=cfg_dir,
                                       path='all_wing_buffs.json',
                                       mimetype='application/json')

    if not user:
        return jsonify({"error": "No The User"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "No The User"}), 404

    raw_data = database.get_user_field(user, "wing_buffs")
    data = json.loads(raw_data) if raw_data else []

    return jsonify({
        "result": "ok",
        "wing_buffs": [
            {
                "name": wb,
                "collected": True,
                "deposited": False,
                "last_conversion": 0,
                "deposit_id": 0
            }
            for wb in data
        ]
    })

@account_bp.route("/get_pending_messages", methods=["POST"])
def get_pending_messages():
    """待收 / 已发礼物消息。

    ★★ 2026-10-03 修「给蜡烛之后对方没有接受按钮」：
       以前这里直接发静态的 config/pending.json（`{"set_sent_messages": [],
       "set_recvd_messages": []}` 两个空数组），所以**对方永远看不到任何待处理消息**，
       自然也就没有"接受"入口。
       现在改成读 gift_messages 表（`/account/give_candle`、`account/send_message`
       写入的那张表），回包键名保持原样 `set_recvd_messages` / `set_sent_messages`
       （已由 pending.json 与 libBootloader.so 两处交叉确认）。
    """
    req = request.get_json(force=True, silent=True) or {}
    me = _pick_any(req, "user", "user_id", "account", "id")
    recvd, sent = [], []
    if me:
        try:
            rows = database.query_all(
                "SELECT msg_id, from_user, to_user, gift_type, currency_type, "
                "currency_count, raw_message, sent_at, claimed FROM gift_messages "
                "WHERE to_user = ? AND claimed = 0 ORDER BY sent_at DESC LIMIT 100", (me,))
            for r in rows or []:
                recvd.append(_gift_entry(r, True))
            rows = database.query_all(
                "SELECT msg_id, from_user, to_user, gift_type, currency_type, "
                "currency_count, raw_message, sent_at, claimed FROM gift_messages "
                "WHERE from_user = ? ORDER BY sent_at DESC LIMIT 100", (me,))
            for r in rows or []:
                sent.append(_gift_entry(r, False))
        except Exception as e:
            _social_log("get_pending_messages.err", repr(e))
    # ★ `sent_message` 是**单数**：客户端的 syncAction 就叫 `sent_message`，
    #   客户端拿一个"最新已发消息对象"（不是数组）去解析；以前这里给数组 →
    #   "Failed to parse resource sync response ... for syncAction sent_message"。
    return jsonify({
        "result": "ok", "status": "ok", "ok": True,
        "set_recvd_messages": recvd,
        "set_sent_messages": sent,
        "recvd_messages": recvd,
        "sent_message": (sent[0] if sent else None),
        "recv_count": len(recvd),
        "sent_count": len(sent),
    })

@account_bp.route("/get_app_badge_number", methods=["POST"])
def get_app_badge_number():
    cfg = load_config()
    return jsonify({"set_app_badge_number": 0})

@account_bp.route("/consumable/get_consumables1", methods=["POST"])
def get_consumables1():
    cfg = load_config()
    return jsonify({"get_consumables": []})

@account_bp.route("/buff/get_buffs1", methods=["POST"])
def get_buffs1():
    cfg = load_config()
    return jsonify({
        "get_buffs": [],
        "get_buffs_sign": "7278445a3c62837da07e5a3505b1a15e7169f34264d2a51a0a187a4dda611397"
    })

@account_bp.route("/lootboxes/get", methods=["POST"])
def get_lootboxes():
    cfg = load_config()
    return jsonify({"get_lootboxes": []})

# ================================================================
# 一次性传送：客户端状态面板的「去空巢」按钮 → 让下一次进图直接落到目标关卡
#   写一个带过期时间的小文件，get_checkpoints 命中即把该关卡当作出生点下发；
#   客户端重启游戏后重新走 get_checkpoints，于是直接进目标图。
#   2 分钟过期，避免用户在目标图里再切图时被反复拉回去。
# ================================================================
_GOTO_FILE = os.path.join(tempfile.gettempdir(), "wbsky_goto.json")
_GOTO_TTL = 300

# level_id 全部 = FNV-1a-32(关卡代号)，已用 9 个已知 ID 校验通过
_GOTO_TARGETS = {
    # 常驻地图
    "home": 3526133726,        # CandleSpace —— 遇境
    "candlespace": 3526133726,
    "skyhub": 2825107789,      # SkyHub2 —— 空巢 / 云巢
    "skyhub2": 2825107789,
    "dawn": 1649439303,        # Dawn —— 晨岛
    "prairie": 927037567,      # Prairie —— 云野
    "rain": 164626931,         # Rain —— 雨林
    "valley": 1638008359,      # Sunset —— 霞谷
    "sunset": 1638008359,
    "dusk": 1147491976,        # Dusk —— 暮土
    "night": 2358907137,       # Night —— 禁阁
    "storm": 1705189686,       # Storm —— 暴风眼
    # 子地图（细分出生点）
    "dawncave": 748712866,     # DawnCave —— 晨岛试炼洞窟
    "dayhubcave": 2394719185,  # DayHubCave —— 八人门洞穴
    "hubreveal": 2018906977,   # HubReveal —— 开场 reveal（无传送打坐点）
    "duskstart": 817373972,    # DuskStart
    "duskmid": 1597085778,     # DuskMid
    "duskend": 4158956653,     # DuskEnd
    "night2": 2307461961,      # Night2
    "nightend": 2267185542,    # NightEnd
    "stormstart": 3110721718,  # StormStart
    "stormend": 3479786579,    # StormEnd
}

# 面板"设置 - 出生点"里给客户端展示的清单（顺序 = 显示顺序）
SPAWN_CHOICES = [
    {"key": "home",     "name": "遇境",     "level_id": 3526133726},
    {"key": "skyhub",   "name": "空巢",     "level_id": 2825107789},
    {"key": "dawn",     "name": "晨岛",     "level_id": 1649439303},
    {"key": "prairie",  "name": "云野",     "level_id": 927037567},
    {"key": "rain",     "name": "雨林",     "level_id": 164626931},
    {"key": "valley",   "name": "霞谷",     "level_id": 1638008359},
    {"key": "dusk",     "name": "暮土",     "level_id": 1147491976},
    {"key": "night",    "name": "禁阁",     "level_id": 2358907137},
    {"key": "storm",    "name": "暴风眼",   "level_id": 1705189686},
]


# ================================================================
# 玩家偏好（出生点 / 身高 / 大小 / 蜡烛 / 光翼数量）
#   存 config/user_prefs.json，不改表结构；字段缺省 = 用全局默认
#   面板「设置」页拖滑条 → POST /account/prefs {user, prefs:{...}}
# ================================================================
_PREFS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                           "config", "user_prefs.json")
_prefs_lock = threading.Lock()

_PREFS_KEYS = ("spawn", "height", "scale", "candles", "wingbuffs")


def _load_prefs_all():
    try:
        with open(_PREFS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_prefs_all(d):
    tmp = _PREFS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _PREFS_FILE)


def _get_prefs(user_id):
    if not user_id:
        return {}
    with _prefs_lock:
        all_d = _load_prefs_all()
    p = all_d.get(str(user_id))
    if not isinstance(p, dict):
        return {}
    return {k: v for k, v in p.items() if k in _PREFS_KEYS}


def _set_prefs(user_id, patch):
    with _prefs_lock:
        all_d = _load_prefs_all()
        cur = all_d.get(str(user_id))
        if not isinstance(cur, dict):
            cur = {}
        for k, v in (patch or {}).items():
            if k not in _PREFS_KEYS:
                continue
            if v is None:
                cur.pop(k, None)
            else:
                cur[k] = v
        all_d[str(user_id)] = cur
        _save_prefs_all(all_d)
        return dict(cur)


def _int_or_none(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _float_or_none(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ================================================================
# 当前玩家识别
#   客户端是 IL2CPP，Java 层拿不到游戏的 user id。两条路：
#   1) 客户端扫自己沙箱里的文本文件，把候选 UUID 发来 → /account/whoami 校验
#      （users 表里存在的那个才是真号）
#   2) 兜底：服务端记住"最近活跃的 user"，面板不带 user 时用它
# ================================================================
_recent_users = {}
_recent_lock = threading.Lock()
_RECENT_TTL = 900


def _note_recent(user, ip):
    try:
        with _recent_lock:
            _recent_users[str(user)] = (ip or "", time.time())
            if len(_recent_users) > 800:
                now = time.time()
                for k in [k for k, v in list(_recent_users.items())
                          if now - v[1] > _RECENT_TTL]:
                    _recent_users.pop(k, None)
    except Exception:
        pass


def _guess_user(ip):
    now = time.time()
    with _recent_lock:
        items = list(_recent_users.items())
    best = None
    for u, (uip, ts) in items:
        if now - ts > _RECENT_TTL:
            continue
        if ip and uip == ip and (best is None or ts > best[1]):
            best = (u, ts)
    if best:
        return best[0]
    alive = [(u, v[1]) for u, v in items if now - v[1] <= 180]
    return alive[0][0] if len(alive) == 1 else None


@account_bp.before_request
def _account_note_user():
    """顺手记录每个带 user 的请求 → 给「最近活跃」兜底用。"""
    if request.method != "POST":
        return None
    try:
        d = request.get_json(force=True, silent=True) or {}
        u = d.get("user")
        if u:
            _note_recent(u, request.remote_addr)
    except Exception:
        pass
    return None


@account_bp.route("/whoami", methods=["POST"])
def whoami():
    """客户端把本地扫到的候选 UUID 发来，返回 users 表里真实存在的那个。"""
    req = request.get_json(force=True, silent=True) or {}
    for c in (req.get("candidates") or []):
        if isinstance(c, str) and database.user_exists(c):
            return jsonify({"ok": True, "user": c, "from": "candidates"})
    u = _guess_user(request.remote_addr)
    return jsonify({"ok": bool(u), "user": u or "", "from": "recent"})


@account_bp.route("/prefs", methods=["POST"])
def user_prefs():
    """读/写玩家偏好。带 prefs 字段 = 写入，否则 = 读取。user 可省略。"""
    req = request.get_json(force=True, silent=True) or {}
    user_id = req.get("user") or _guess_user(request.remote_addr)
    if not user_id:
        return jsonify({"error": "Missing user_id"}), 400
    patch = req.get("prefs")
    if isinstance(patch, dict):
        patch = dict(patch)
        if "spawn" in patch:
            sp = patch["spawn"]
            if isinstance(sp, str):
                sp = _GOTO_TARGETS.get(sp.strip().lower(), 0)
            patch["spawn"] = _int_or_none(sp) or 0
        for k in ("candles", "wingbuffs"):
            if k in patch:
                patch[k] = _int_or_none(patch[k])
        for k in ("height", "scale"):
            if k in patch:
                patch[k] = _float_or_none(patch[k])
        cur = _set_prefs(user_id, patch)
        return jsonify({"result": "ok", "prefs": cur})
    return jsonify({"result": "ok", "prefs": _get_prefs(user_id),
                    "spawn_choices": SPAWN_CHOICES})


def _set_forced_level(level_id):
    with open(_GOTO_FILE, "w") as f:
        json.dump({"level": int(level_id), "expire": time.time() + _GOTO_TTL}, f)


def _take_forced_level():
    """读取传送标记；过期则丢弃。未过期时**不消费**（TTL 内持续生效）。"""
    try:
        with open(_GOTO_FILE) as f:
            d = json.load(f)
    except Exception:
        return None
    if float(d.get("expire", 0)) < time.time():
        try:
            os.remove(_GOTO_FILE)
        except OSError:
            pass
        return None
    return d.get("level")


@account_bp.route("/goto_level", methods=["POST"])
def goto_level():
    """面板按钮用：设置一次性传送目标 {target: "skyhub" | level_id: 2825107789}"""
    req = request.get_json(force=True, silent=True) or {}
    raw = req.get("target")
    if raw is None:
        raw = req.get("level_id")
    if isinstance(raw, str):
        lv = _GOTO_TARGETS.get(raw.strip().lower())
    else:
        try:
            lv = int(raw)
        except (TypeError, ValueError):
            lv = None
    if not lv:
        return jsonify({"ok": False, "msg": "未知的传送目标"}), 400
    try:
        _set_forced_level(lv)
    except Exception as e:
        return jsonify({"ok": False, "msg": "写入失败: %s" % e}), 500
    return jsonify({"ok": True, "level_id": int(lv),
                    "msg": "已设置目标关卡，重进游戏即传送"})


@account_bp.route("/get_checkpoints", methods=["POST"])
def get_checkpoints():
    req = request.get_json(force=True, silent=True) or {}
    user_id = req.get("user")

    if not user_id:
        return jsonify({"error": "Cannot find latest checkpoint"}), 400

    # ============================================================
    # Sky 0.15.5 版本 checkpoint 适配
    # build_version: 179644 (Android) / 179535 (iOS) / 179482 (Switch)
    # level_id = FNV-1a-32(map_codename)
    # 已验证: Dawn -> 1649439303, CandleSpace -> 3526133726
    # ============================================================

    # 晨岛（Dawn / Isle）
    DAWN_LEVEL_ID = 1649439303       # FNV-1a("Dawn")
    DAWN_LEVEL_ID_OLD = 1649439403   # MAPID.txt 记录的旧版 ID

    # 试炼洞窟（DawnCave / Trials Cave）
    DAWN_CAVE_LEVEL_ID = 748712866   # FNV-1a("DawnCave")

    # 八人门洞穴（DayHubCave）
    DAY_HUB_CAVE_LEVEL_ID = 2394719185  # FNV-1a("DayHubCave")

    # 遇境枢纽（HubReveal）- 出生点
    HUB_REVEAL_LEVEL_ID = 2018906977   # FNV-1a("HubReveal")

    # 遇境（Home / CandleSpace）
    HOME_LEVEL_ID = 3526133726       # FNV-1a("CandleSpace")

    # 遇境别名关卡（SkyHub2）- 客户端里与 CandleSpace 共用同一份地图数据
    # （BstBaked.meshes / Objects.level 哈希完全一致，Resources.lua 引用 Levels/CandleSpace/*）
    # 客户端进入 SkyHub2 / 联机都需要服务端把它当作已知关卡下发，否则闪退 / 落到 CandleSpace
    SKY_HUB2_LEVEL_ID = 2825107789   # FNV-1a("SkyHub2")

    # 云野（Prairie / Day）
    PRAIRIE_LEVEL_ID = 3265870096
    PRAIRIE_LEVEL_ID_FNVA = 927037567  # FNV-1a("Prairie")

    # 雨林（Forest / Rain）
    FOREST_LEVEL_ID = 2889552629
    FOREST_LEVEL_ID_FNVA = 164626931  # FNV-1a("Rain")

    # 霞谷（Valley / Sunset）
    VALLEY_LEVEL_ID = 1007551460
    VALLEY_LEVEL_ID_FNVA = 1638008359  # FNV-1a("Sunset")

    # ★ 云野/雨林/霞谷门真实目标代号（2026-10-02 反汇编补）——
    #   空巢门挂的目标关卡代号不是"地图代号"，而是 Day/Rain/Sunset 这套：
    #   云野门 → DayHubCave, DayEnd, Day；雨林门 → Rain, RainEnd；
    #   霞谷门 → SunsetRace, SunsetEnd, Sunset, SunsetEnd2。
    DAY_LEVEL_ID = 1230250653            # FNV-1a("Day")
    DAY_END_LEVEL_ID = 1190972738        # FNV-1a("DayEnd")
    RAIN_END_LEVEL_ID = 128844448        # FNV-1a("RainEnd")
    SUNSET_RACE_LEVEL_ID = 571720490     # FNV-1a("SunsetRace")
    SUNSET_END_LEVEL_ID = 2360310676     # FNV-1a("SunsetEnd")
    SUNSET_END2_LEVEL_ID = 507487826     # FNV-1a("SunsetEnd2")

    # ★ 暮土 / 禁阁 / 暴风眼（2026-10-02 补）——
    #   之前**从来没下发过**（见 MAPID.txt：这三张图标着"level_id 未知"）。
    #   空巢/遇境里通往各图的门是按「我有没有去过目标关卡」判定的：客户端里每个门
    #   （LevelGatesDusk_01 / LevelGatesNight_01 / LevelGatesStorm_01 …）都挂着一份
    #   目标关卡列表，关卡不在 checkpoint 里 → 客户端认为"还没去过" → 门口生成风墙
    #   （星座门阻挡体 constellation_gate_blocked_passage），只能从门顶飞过去。
    #   level_id = FNV-1a-32(关卡代号)，已用 9 个已知 ID 校验全部一致。
    DUSK_START_LEVEL_ID = 817373972       # FNV-1a("DuskStart")
    DUSK_LEVEL_ID = 1147491976            # FNV-1a("Dusk")
    DUSK_GRAVEYARD_LEVEL_ID = 864432821   # FNV-1a("DuskGraveyard")
    DUSK_MID_LEVEL_ID = 1597085778        # FNV-1a("DuskMid")
    DUSK_END_LEVEL_ID = 4158956653        # FNV-1a("DuskEnd")
    NIGHT_LEVEL_ID = 2358907137           # FNV-1a("Night")
    NIGHT2_LEVEL_ID = 2307461961          # FNV-1a("Night2")
    NIGHT_END_LEVEL_ID = 2267185542       # FNV-1a("NightEnd")
    STORM_START_LEVEL_ID = 3110721718     # FNV-1a("StormStart")
    STORM_LEVEL_ID = 1705189686           # FNV-1a("Storm")
    STORM_END_LEVEL_ID = 3479786579       # FNV-1a("StormEnd")

    # 0.15.x 版本需要 16 个 True 状态
    # 确保打坐点/冥想点已激活、神庙大门开启、无空气墙
    FULL_STATES = [True] * 16

    # ★ 出生点规则（2026-09-15）：
    #   新号（未到过遇境）→ 出生在遇境枢纽 HubReveal（新手引导）
    #   到过遇境 CandleSpace / SkyHub2 的账号 → 之后每次登录都出生在遇境
    visited_home = int(database.get_user_field(user_id, "visited_home") or 0)
    if not visited_home:
        # 兼容老账号：最近一次 checkpoint 就是遇境（CandleSpace / SkyHub2 同图），
        # 或解锁记录里已有 first_loaded_CandleSpace / first_loaded_SkyHub2
        try:
            cp = database.get_user_field(user_id, "checkpoint")
            if cp is not None and int(cp) in (HOME_LEVEL_ID, SKY_HUB2_LEVEL_ID):
                visited_home = 1
        except (TypeError, ValueError):
            pass
    if not visited_home:
        try:
            raw = database.get_user_field(user_id, "unlocks")
            if raw:
                unlocks = json.loads(raw)
                if any(u.get("name") in ("first_loaded_CandleSpace", "first_loaded_SkyHub2", "SkyHubFirstArrival") for u in unlocks):
                    visited_home = 1
        except Exception:
            pass
    if visited_home:
        database.set_user_field(user_id, "checkpoint", HOME_LEVEL_ID)
        dawn_furthest = False
        home_furthest = True
    else:
        # ★ 出生点规则（2026-09-18）：首次进入出生在晨岛 Dawn（初始地图），
        #   并立即标记 visited_home=1 → 第二次及以后每次登录统一出生在遇境 CandleSpace
        database.set_user_field(user_id, "checkpoint", DAWN_LEVEL_ID)
        database.set_user_field(user_id, "visited_home", 1)
        dawn_furthest = True
        home_furthest = False

    # ★ 一次性传送标记（面板「去空巢」按钮）：命中则无视常规出生点，直接落到目标关卡
    forced = _take_forced_level()
    if forced:
        print("[GOTO] user=%s -> level_id=%s (一次性传送)" % (user_id, forced), flush=True)

    # ★ 面板「设置 - 出生点」里选定的常驻出生点（一次性标记优先）
    if not forced:
        spawn = _int_or_none(_get_prefs(user_id).get("spawn"))
        if spawn:
            forced = spawn
            print("[SPAWN] user=%s -> level_id=%s (自定义出生点)"
                  % (user_id, spawn), flush=True)

    if forced:
        return jsonify({"checkpoints": [{
            "user": user_id,
            "level_id": int(forced),
            "level_hash": 42128,
            "bst_id": 7,
            "states": FULL_STATES,
            "is_furthest": True,
            "arc_order": 7
        }]})

    checkpoints = []

    # 1. 晨岛（Dawn）- 出生点（首次进入），同时下发两个 ID
    checkpoints.append({
        "user": user_id,
        "level_id": DAWN_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": dawn_furthest,
        "arc_order": 7
    })
    checkpoints.append({
        "user": user_id,
        "level_id": DAWN_LEVEL_ID_OLD,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })

    # 2. 八人门洞穴（DayHubCave）- 已通关
    checkpoints.append({
        "user": user_id,
        "level_id": DAY_HUB_CAVE_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })

    # 3. 试炼洞窟（DawnCave）- 已通关
    checkpoints.append({
        "user": user_id,
        "level_id": DAWN_CAVE_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })

    # 遇境枢纽（HubReveal）- 已知关卡（非出生点，放在列表后部）
    checkpoints.append({
        "user": user_id,
        "level_id": HUB_REVEAL_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })

    # 5. 遇境（Home / CandleSpace）- 到过遇境的账号以此为出生点
    checkpoints.append({
        "user": user_id,
        "level_id": HOME_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": home_furthest,
        "arc_order": 19
    })

    # 5b. 遇境别名关卡（SkyHub2）- 与 CandleSpace 同地图，必须作为已知关卡下发，
    #     否则客户端进入 SkyHub2 会闪退、或导航被拉回 CandleSpace
    checkpoints.append({
        "user": user_id,
        "level_id": SKY_HUB2_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 19
    })

    # 6. 云野（Prairie / Day）- 同时下发两个 ID 确保兼容
    checkpoints.append({
        "user": user_id,
        "level_id": PRAIRIE_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 3
    })
    checkpoints.append({
        "user": user_id,
        "level_id": PRAIRIE_LEVEL_ID_FNVA,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 3
    })

    # 7. 雨林（Forest / Rain）- 同时下发两个 ID
    checkpoints.append({
        "user": user_id,
        "level_id": FOREST_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 5
    })
    checkpoints.append({
        "user": user_id,
        "level_id": FOREST_LEVEL_ID_FNVA,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 5
    })

    # 8. 霞谷（Valley / Sunset）- 同时下发两个 ID
    checkpoints.append({
        "user": user_id,
        "level_id": VALLEY_LEVEL_ID,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })
    checkpoints.append({
        "user": user_id,
        "level_id": VALLEY_LEVEL_ID_FNVA,
        "level_hash": 42128,
        "bst_id": 7,
        "states": FULL_STATES,
        "is_furthest": False,
        "arc_order": 7
    })

    # 8b. ★ 云野/雨林/霞谷门的「真实目标关卡代号」补发 —— 2026-10-02 反汇编定论
    #     客户端空巢里的门（hub_doorN / LevelGates）判定"能不能进"看的是
    #     「目标关卡在不在 get_checkpoints 列表里」，不在 = "还没去过" = 风墙。
    #     反汇编 SkyHub2/Objects.level.bin 发现门挂的目标代号是：
    #       云野门 → DayHubCave, DayEnd, Day
    #       雨林门 → Rain, RainEnd
    #       霞谷门 → SunsetRace, SunsetEnd, Sunset, SunsetEnd2
    #     之前只按"地图代号"（Prairie/Forest/Valley）下发，跟门挂的代号
    #     （Day/Rain/Sunset 这套）对不上，所以风墙一直没消除。
    for _lid, _arc in (
        (DAY_LEVEL_ID, 3), (DAY_END_LEVEL_ID, 3),        # 云野门
        (RAIN_END_LEVEL_ID, 5),                            # 雨林门
        (SUNSET_RACE_LEVEL_ID, 7), (SUNSET_END_LEVEL_ID, 7),
        (SUNSET_END2_LEVEL_ID, 7),                         # 霞谷门
    ):
        checkpoints.append({
            "user": user_id,
            "level_id": _lid,
            "level_hash": 42128,
            "bst_id": 7,
            "states": FULL_STATES,
            "is_furthest": False,
            "arc_order": _arc
        })

    # 9. ★ 暮土（Dusk）/ 禁阁（Night）/ 暴风眼（Storm）——
    #    主关卡 + 各分图全部下发，否则空巢里这三个门会有风墙（"还没去过"）。
    for _lid, _arc in (
        (DUSK_START_LEVEL_ID, 9), (DUSK_LEVEL_ID, 9), (DUSK_GRAVEYARD_LEVEL_ID, 9),
        (DUSK_MID_LEVEL_ID, 9), (DUSK_END_LEVEL_ID, 9),
        (NIGHT_LEVEL_ID, 11), (NIGHT2_LEVEL_ID, 11), (NIGHT_END_LEVEL_ID, 11),
        (STORM_START_LEVEL_ID, 13), (STORM_LEVEL_ID, 13), (STORM_END_LEVEL_ID, 13),
    ):
        checkpoints.append({
            "user": user_id,
            "level_id": _lid,
            "level_hash": 42128,
            "bst_id": 7,
            "states": FULL_STATES,
            "is_furthest": False,
            "arc_order": _arc
        })

    # ★ 出生点优先级（客户端按 checkpoint 列表第一个进图）：
    #   首次进入（未到过遇境）→ Dawn 置顶；二次及以后（到过遇境）→ CandleSpace 置顶
    if home_furthest:
        checkpoints.sort(key=lambda x: 0 if x["level_id"] == HOME_LEVEL_ID else 1)
    else:
        checkpoints.sort(key=lambda x: 0 if x["level_id"] in (DAWN_LEVEL_ID, DAWN_LEVEL_ID_OLD) else 1)

    # ⚠️ 曾经这里有一段排障用的 TEMP-DEBUG，会把指定账号的出生点强制改成
    #   HubReveal（遇境枢纽 = 开场 reveal 用的"intro home"）。已删除，原因：
    #   ① 那个关卡没有"传送打坐点"，被强制进去的账号**出不来**（不能传送）；
    #   ② 它和其它账号的 CandleSpace 是**两个不同关卡** → 联机分组不同 → 同一张图
    #      里永远看不到对方。教训：排障开关用完必须删，且不要写死具体 user_id。

    return jsonify({
        "checkpoints": checkpoints
    })

@account_bp.route("/get_external_friends", methods=["POST"])
def get_external_friendsmethods():
    cfg = load_config()
    return jsonify({"external_account_friends": []})

@account_bp.route("/serendipity/get", methods=["POST"])
def get_serendipity():
    cfg = load_config()
    return jsonify({"serendipity_matches": []})

@account_bp.route("/serendipity/join", methods=["POST"])
def serendipity_join():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user", "")
    # serendipity（随机邂逅）加入匹配：当前实现返回空匹配池
    return jsonify({
        "serendipity_update": {
            "type": "serendipity_match_join",
            "matches": [],
            "join_confirm": True,
            "user": user
        }
    })


@account_bp.route("/star/get", methods=["POST"])
def get_star_nfc():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='stars_config.json',
        mimetype='application/json'
    )

@account_bp.route("/get_outfit", methods=["POST"])
def get_outfit():
    req = request.get_json(force=True, silent=True) or {}
    user_id = req.get("user")
    if not user_id:
        return jsonify({"error": "Missing user_id"}), 400

    if not database.user_exists(user_id):
        return jsonify({"error": "User not found"}), 404

    fields = (
        "outfit_wing", "outfit_prop", "outfit_face", "outfit_mask",
        "outfit_hair", "outfit_body", "outfit_arms", "outfit_feet",
        "outfit_hat", "outfit_horn", "outfit_neck", "outfit_height"
    )
    row = database.query_one(
        f"SELECT {','.join(fields)} FROM users WHERE id = ?", (user_id,)
    )
    # ★ 修复「衣服不保存 / 外观变默认」：清库后新建的账号 outfit_* 全是建表默认 0，
    #   客户端拿到全 0 就渲染成裸装；这里补成默认装扮（缺哪项补哪项）。
    if not row or not any(row.get(f) for f in fields):
        defaults = {
            "outfit_wing": 2245279351,
            "outfit_prop": 2035109393,
            "outfit_face": 0,
            "outfit_mask": 3663390882,
            "outfit_hair": 1229053584,
            "outfit_body": 3691343236,
            "outfit_arms": 0,
            "outfit_feet": 0,
            "outfit_hat": 0,
            "outfit_horn": 0,
            "outfit_neck": 0,
            "outfit_height": -0.34827823582230427
        }
        database.execute(
            "UPDATE users SET " +
            ", ".join([f"{k}=?" for k in defaults]) +
            " WHERE id=?",
            (*defaults.values(), user_id)
        )
        if not row:
            row = defaults
        else:
            row = dict(row)
            row.update(defaults)

    # ★ 面板「设置」里的身高 / 大小（拖滑条），有值就覆盖。**必须夹紧到客户端合法区间**
    #   （客户端 `kOutfitAvatarHeight | -3.0 3.0`；越界会被丢弃 → 身高失效、高个子漂浮）
    _p = _get_prefs(user_id)
    _ph = _clamp_h(_float_or_none(_p.get("height")))
    _ps = _clamp_h(_float_or_none(_p.get("scale")), -3.0, 3.0)

    # row 是 dict，按字段名访问
    # ★ _clean_outfit：把 id==0 的槽位去掉（否则客户端每帧刷
    #   "Outfit slot is falling back to default since ID 0 is not found!"）
    return jsonify({
        "result": "ok",
        "set_outfit": _clean_outfit({
            "wing": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_wing"]},
            "voice": 0,
            "seed": 39450,
            "scale": _ps if _ps is not None else -0.0810321030110921,
            "prop": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_prop"]},
            "neck": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_neck"]},
            "mask": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_mask"]},
            "horn": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_horn"]},
            "height": _clamp_h(_ph if _ph is not None else row["outfit_height"]),
            "hat": {"id": row["outfit_hat"]},
            "hair": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_hair"]},
            "feet": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_feet"]},
            "face": {"id": row["outfit_face"]},
            "body": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_body"]},
            "attitude": "0",
            "arms": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_arms"]}
        })
    })

# ══════════════════════════════════════════════════════════════════
# 装扮：别人的外观（远端玩家）
#
# ★★ 2026-10-03 用户实测：能看到人、能开好友树，但「看不到装扮、也看不到身高，
#    高的人直接漂浮」。根因：客户端会为每个看到的玩家请求
#        POST /account/get_remote_outfit  {"user":我, "session":…, "target":对方}
#    而我们没实现这个路由 → 被 catch-all 兜成 `{}` → 客户端
#    （libBootloader.so 里的 AccountRemoteOutfitRequest）解析失败、退回默认模型：
#      卤蛋头 + 默认身高（身高/大小来自这里：日志 "Request update - height or scale:
#      Client: (height …) Cache: (height …)"）。
#    客户端还会校验回包 target 是否与请求一致（"Response target desynced %s != %s"），
#    所以 target 必须原样回显。另外 /account/set_outfit 也一直是 `{}` → 自己的
#    装扮改动根本没落库。
# ══════════════════════════════════════════════════════════════════
_OUTFIT_DB_FIELDS = (
    "outfit_wing", "outfit_prop", "outfit_face", "outfit_mask",
    "outfit_hair", "outfit_body", "outfit_arms", "outfit_feet",
    "outfit_hat", "outfit_horn", "outfit_neck", "outfit_height"
)

_DEFAULT_OUTFIT = {
    "outfit_wing": 2245279351,
    "outfit_prop": 2035109393,
    "outfit_face": 0,
    "outfit_mask": 3663390882,
    "outfit_hair": 1229053584,
    "outfit_body": 3691343236,
    "outfit_arms": 0,
    "outfit_feet": 0,
    "outfit_hat": 0,
    "outfit_horn": 0,
    "outfit_neck": 0,
    "outfit_height": -0.34827823582230427,
}

# 客户端 kOutfitSlot_* 在 libBootloader.so 字符串表里就是这个顺序
_OUTFIT_SLOT_ENUM = {"body": 0, "wing": 1, "hair": 2, "mask": 3, "neck": 4,
                     "feet": 5, "horn": 6, "arms": 7, "prop": 8}

# ★★ 每个槽位"空"项的真实 id = FNV-1a-32("CharSkyKid_<Slot>_None")
#    （在 config/outfit_defs.json 里按 name 前缀找到、网格为 Outfit_None 的条目；
#      FNV-1a-32 公式已用 11 个已知 id 全量校验命中，见 _clean_outfit 注释。）
#    ⚠️ `arms` 不是客户端的槽位，故无此表项。
_NONE_OUTFIT_IDS = {
    "body": 1502671700,   # CharSkyKid_Body_Museum   (mesh Outfit_None)
    "face": 3599986885,   # CharSkyKid_Face_None
    "feet": 1532093990,   # CharSkyKid_Feet_None
    "hair": 1740771042,   # CharSkyKid_Hair_None
    "hat": 1470462579,    # CharSkyKid_Hat_None
    "horn": 3680499229,   # CharSkyKid_Horn_None
    "mask": 4267756678,   # CharSkyKid_Mask_None
    "neck": 3800884691,   # CharSkyKid_Neck_None
    "prop": 2035109393,   # CharSkyKid_Prop_None
    "wing": 1324678683,   # CharSkyKid_Wing_None
}

_REMOTE_OUTFIT_SEQ = {"n": 0}


def _load_outfit_row(user_id):
    """读装扮行；全是 0（清库后新账号）就补默认值并写回。"""
    row = database.query_one(
        f"SELECT {','.join(_OUTFIT_DB_FIELDS)} FROM users WHERE id = ?", (user_id,)
    )
    if not row or not any(row.get(f) for f in _OUTFIT_DB_FIELDS):
        if database.user_exists(user_id):
            database.execute(
                "UPDATE users SET " + ", ".join(f"{k}=?" for k in _DEFAULT_OUTFIT) + " WHERE id=?",
                (*_DEFAULT_OUTFIT.values(), user_id)
            )
        row = dict(row) if row else {}
        row.update(_DEFAULT_OUTFIT)
    return dict(row)


_OUTFIT_WHITELIST_CACHE = {"data": None, "mtime": 0}


def _outfit_whitelist():
    """读客户端**真实**装扮表白名单 config/outfit_id_whitelist.json。

    ★★★ 2026-10-03 终极定位（这一条推翻了之前所有关于 id 的猜测）：
      客户端的装扮表**不是**服务端下发的那份 `config/outfit_defs.json`，
      而是它自带的 APK 资源 `assets/Data/Resources/OutfitDefs.json`
      （432 条；`.so` 里既没有 `outfit_defs` 也没有 `get_outfit_defs` 字符串
      ⇒ 客户端**从不调用** `/account/get_outfit_defs`）。
      实证：`libBootloader.so` 0x1042900~0x1042a84 整片连续字段名
      （`color_hsv / pattern_hsv / tint_hsv / skipMotionBlur / hornOffset /
        putBackAnimSeq / disableBody …`）**只存在于 APK 那份 schema**；
      而我们 `outfit_defs.json` 的键（`diffuseTex / inCloset / base_hsv /
      maskTex / icon_hsv / dyeable_primary …`）在 .so 里**一个都没有**。
      ⇒ 两套 schema 完全不同；客户端那份只有 **7 个槽位**
        （body / hair / horn / mask / neck / prop / wing），
        **没有 face / hat / arms**，也**没有 feet** 的任何条目。
    """
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                        "config", "outfit_id_whitelist.json")
    try:
        mt = os.path.getmtime(path)
        if _OUTFIT_WHITELIST_CACHE["data"] is None or _OUTFIT_WHITELIST_CACHE["mtime"] != mt:
            with open(path, encoding="utf-8") as f:
                _OUTFIT_WHITELIST_CACHE["data"] = json.load(f)
            _OUTFIT_WHITELIST_CACHE["mtime"] = mt
    except Exception as e:
        _OUTFIT_WHITELIST_CACHE["data"] = None
        try:
            _social_log("outfit_whitelist.err", repr(e))
        except Exception:
            pass
    return _OUTFIT_WHITELIST_CACHE["data"]


def _clean_outfit(o):
    """只下发客户端**真的认得**的槽位和 id；认不出的一律不发。

    ★★★ 为什么必须这样（真机闭环证据，2026-10-03）：
      上一版我们给 face / feet / hat 三个槽位"补"了 id（其中
      `_NONE_OUTFIT_IDS['body']` 还是 `CharSkyKid_Body_Museum` 这种猜出来的值）。
      但客户端：
        ① 根本没有 `face` / `hat` / `arms` 这三个槽位（`kOutfitSlot_*` 枚举
           只有 Body/Wing/Hair/Mask/Neck/Feet/Horn/Arms/Prop）；
        ② 它的表里也没有 `Face_None` / `Feet_None` / `Hat_None` 这些条目。
      ⇒ **只要回包里出现一个客户端解析不出的槽位，整个 outfit 就回落到内置默认**
        ⇒ 现象「不管对方穿什么，看到的都是同一个默认模型（卤蛋无斗篷）」；
        而"默认装"看起来是好的，**只是因为回落的默认恰好等于默认装**。

    规则：
      · 槽位必须在客户端表里存在（body/wing/hair/mask/neck/horn/prop）；
      · id 必须在白名单里（= FNV-1a-32(name)，name 来自客户端那份 432 条表）；
      · id 不在白名单 → 换成该槽位客户端表里真实的 isDefault 值，绝不发明 id；
      · 连默认都没有 → **整个槽位不发**，让客户端用它自己的默认。
    """
    wl = _outfit_whitelist() or {}
    allowed = wl.get("ids") or {}
    defaults = wl.get("default_by_slot") or {}
    none_by_slot = wl.get("none_by_slot") or {}
    slots = set(wl.get("slots") or ())

    if not allowed:
        # 白名单文件缺失时的保守兜底：只发默认装（值都取自客户端 isDefault）
        slots = {"body", "wing", "hair", "mask", "neck", "horn", "prop"}
        defaults = {k: v for k, v in _DEFAULT_OUTFIT.items()}
        allowed = {}
        for k, v in _DEFAULT_OUTFIT.items():
            if v:
                allowed[str(v)] = k

    out = {}
    for k, v in o.items():
        if not isinstance(v, dict):
            out[k] = v
            continue
        if k not in slots:
            continue                      # face / hat / arms / feet：客户端没有
        try:
            i = int(v.get("id") or 0)
        except (TypeError, ValueError):
            i = 0
        if str(i) not in allowed:
            i = int(defaults.get(k) or none_by_slot.get(k) or 0)
        if not i or (allowed and str(i) not in allowed):
            continue                      # 没有合法值 → 这个槽位干脆不发
        out[k] = dict(v, id=i)
    return out


def _clamp_h(v, lo=-3.0, hi=3.0):
    """身高/大小必须落在客户端的合法区间内。

    ★ 客户端字符串里有 `kOutfitAvatarHeight | -3.0 3.0`；真机请求记录里出现过
      `height = -4.0`（面板滑条越界）⇒ 客户端直接丢弃该值 ⇒ 渲染默认身高
      ⇒ **高个子玩家看起来在漂浮**。这里统一夹紧。
    """
    if v is None:
        return None
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return None


def _outfit_payload(user_id, row=None):
    """组装客户端认的 set_outfit 结构 —— 与 /account/get_outfit 保持完全一致
    （那条路径客户端日志是 "Successfully read outfit from server"，已验证可用）。"""
    if row is None:
        row = _load_outfit_row(user_id)
    p = _get_prefs(user_id)
    ph = _clamp_h(_float_or_none(p.get("height")))
    ps = _clamp_h(_float_or_none(p.get("scale")), -3.0, 3.0)
    return _clean_outfit({
        "wing": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_wing"]},
        "voice": 0,
        "seed": 39450,
        "scale": ps if ps is not None else -0.0810321030110921,
        "prop": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_prop"]},
        "neck": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_neck"]},
        "mask": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_mask"]},
        "horn": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_horn"]},
        "height": _clamp_h(ph if ph is not None else row["outfit_height"]),
        "hat": {"id": row["outfit_hat"]},
        "hair": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_hair"]},
        "feet": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_feet"]},
        "face": {"id": row["outfit_face"]},
        "body": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_body"]},
        "attitude": "0",
    })


@account_bp.route("/get_remote_outfit", methods=["POST"])
def get_remote_outfit():
    """别的玩家穿什么 + 身高/大小（客户端渲染远端光之子用）。"""
    req = request.get_json(force=True, silent=True) or {}
    target = str(req.get("target") or "").strip()
    if not target:
        return jsonify({"error": "Missing target"}), 400

    row = _load_outfit_row(target)
    outfit = _outfit_payload(target, row)
    unlocks = [
        {"type": _OUTFIT_SLOT_ENUM[k], "unlock": v["id"], "slot": k, "id": v["id"],
         "name": k, "option": v["id"]}
        for k, v in outfit.items()
        # 只给客户端真正有的槽位（kOutfitSlot_* 里没有 hat / face，别让它们进来）
        if isinstance(v, dict) and v.get("id") and k in _OUTFIT_SLOT_ENUM
    ]
    _REMOTE_OUTFIT_SEQ["n"] = (_REMOTE_OUTFIT_SEQ["n"] % 100000) + 1
    seq = _REMOTE_OUTFIT_SEQ["n"]

    resp = {
        "result": "ok", "status": "ok", "ok": True,
        # ★ 必须原样回显 target，否则客户端判 "Response target desynced"
        "target": target, "user": target, "id": target,
        "seq": seq, "remote_seq": seq, "remoteSeq": seq, "ack_seq": seq,
        "set_outfit": outfit, "outfit": outfit, "remote_outfit": outfit,
        "unlocks": unlocks, "unlock_count": len(unlocks), "unlocks_count": len(unlocks),
        "height": outfit["height"], "scale": outfit["scale"],
        "attitude": "0", "voice": 0, "seed": outfit["seed"],
        "serendipity_types": [], "voices": [],
    }
    # ★★ 2026-10-03 反汇编定位（libBootloader.so 0x504cc4）：
    #      mov x0,<响应对象>; mov w2,#0x11; add x1,="get_remote_outfit"; bl 查找成员
    #      cbz w0, → 找不到就走另一条路
    #    ⇒ 响应体里**必须存在一个叫 `get_remote_outfit` 的顶层成员**（长度正好 17），
    #      而且同一个函数紧接着还查 `serendipity_types`（也 17）。
    #      所以这里把整份 payload 原样再挂到同名成员下，并补一个 AccountResource
    #      常见的 `set_remote_outfit` 别名 —— 多给的键客户端会忽略，缺键才会掉进默认模型。
    # ★★★ 2026-10-03 关键修正：`get_remote_outfit` 这个顶层成员必须是**装扮本体**。
    #
    #   反汇编 libBootloader.so 0x504cc4：
    #       mov x0,<响应对象>; mov w2,#0x11; add x1,="get_remote_outfit"; bl 查成员; cbz w0 → 跳过
    #   客户端先按这个名字取成员，**取到之后直接拿它当装扮资源解析**
    #   （读 body / wing / hair / mask / neck / horn / prop / height / scale 这些槽位键）。
    #
    #   上一版我把整个 resp（set_outfit / unlocks / target / seq / height …）挂在
    #   这个名字下 —— 那个对象里**没有槽位键**，客户端解析不出任何槽位
    #   ⇒ 整体回落到内置默认模型 ⇒ 现象「身高能看到（height 在顶层被单独读过）、
    #   但装扮永远看不到（一直是卤蛋无斗篷）」。
    #   ⇒ 这里把它设成装扮本体（与 set_outfit 同一份），既安全又对症。
    resp["get_remote_outfit"] = dict(outfit)
    resp["set_remote_outfit"] = dict(outfit)
    _social_log("get_remote_outfit", {"user": _req_user(req), "target": target,
                                      "height": resp["height"], "scale": resp["scale"],
                                      "unlocks": len(unlocks)})
    return jsonify(resp)


@account_bp.route("/get_level_pickups", methods=["POST"])
def get_level_pickups():
    req = request.get_json(force=True, silent=True) or {}
    level = str(req.get("level", "")).strip()

    pickups_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "level_pickups_config")
    file_path = os.path.join(pickups_dir, f"{level}.json")

    if os.path.isfile(file_path):
        return send_from_directory(directory=pickups_dir, path=f"{level}.json",
                                   mimetype='application/json')

    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    log_file = os.path.join(log_dir, "not_found_level.txt")
    os.makedirs(log_dir, exist_ok=True)

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"{datetime.utcnow().isoformat()}Z - {json.dumps(req, ensure_ascii=False)}\n")

    # ★ 关键修复：以前这里直接返回 {}。
    #   客户端解析地图物件（拾取物 / 发射器）配置时是按固定字段读的，
    #   拿到 {} 会因为字段缺失而卡在「地图初始化」阶段 —— 表现就是
    #   「进入该地图后无法移动」。这里返回结构完整的空配置。
    try:
        level_num = int(level)
    except (TypeError, ValueError):
        level_num = 0

    return jsonify({
        "level": level_num,
        "pickups": [],
        "global_pickups": [],
        "pickup_emitters": []
    })

@account_bp.route("/find_previous_or_empty", methods=['POST'])
def find_previous_or_empty():
    """查找可用的 UDP 房间服务器

    客户端通过此接口获取 UDP 服务器地址，用于多人同步和聊天。
    """
    cfg = load_config()

    # ★ 修复：以前 udp_server_host 写死成公网 IP，只要换了机器 / 用局域网 /
    #   用域名访问 HTTP，客户端拿到的 UDP 地址就是错的 —— 结果就是
    #   「进图不能动 / 看不到别人 / 聊不了天 / 联机失败」。
    #   现在支持 "auto"：自动使用客户端本次请求 HTTP 时所用的主机名。
    udp_host = str(cfg.get("udp_server_host", "auto") or "auto").strip()

    # ★ 允许环境变量临时覆盖：docker-compose.yaml 里给 server 容器加一行
    #     WB_SKY_UDP_HOST=103.24.218.98
    #   重启容器即可切回「直连 UDP」，不用改 config.json、不用重建镜像 —— 方便对调
    #   排查「到底该走香港中转还是走本机公网」。留空 / 不设置 = 用 config.json 的值。
    _env = os.environ.get("WB_SKY_UDP_HOST", "").strip()
    if _env:
        udp_host = _env

    if udp_host in ("", "auto", "0.0.0.0", "127.0.0.1", "localhost"):
        udp_host = request.host.split(":")[0]

    try:
        udp_port = int(cfg.get("udp_server_port", 20000))
    except (TypeError, ValueError):
        udp_port = 20000

    udp_uri = f"{udp_host}:{udp_port}"

    # 从请求中获取 session 和 source
    req = request.get_json(force=True, silent=True) or {}
    session = req.get("session", "")
    source = req.get("source", {"type": "random", "id": ""})

    app_logger = current_app.logger if current_app else None
    if app_logger:
        app_logger.info(f"[UDP] 下发房间服务器 {udp_uri} (from {request.host})")

    return jsonify({
        "status": "ok",
        "session": session,
        "source": source,
        "move_ts": int(time.time()),
        "platform_filter": 0,
        "ps_only": False,
        "sig": "4e2aefa017ee95f39211a22b9a90b022f42a8e13497b1e62af828d4391409cc0",
        "signature": "44465d87cbdc0172f9037c1c41ad86a5a22c13c5a75cb8a821bad675ff56899c",
        "uri": udp_uri
    })

@account_bp.route("/link_gamecenter", methods=["POST"])
def link_gamecenter():
    """Game Center 关联接口 - 不记录日志"""
    # 直接返回成功，不触发日志中间件
    # 注意：如果全局日志中间件没有过滤，这个请求还是会触发日志
    return jsonify({
        "result": "ok",
        "linked": True
    })


@account_bp.route("/set_checkpoint", methods=["POST"])
def set_checkpoint():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    level_id = req.get("level_id")
    level_hash = req.get("level_hash", 42128)
    bst_id = req.get("bst_id", 7)
    # 始终返回全部已激活状态(16个True)，与 get_checkpoints 保持一致
    # 确保：1) 打坐点不会因状态不一致而消失 2) 神庙大门保持开启
    states = [True] * 16
    arc_order = req.get("arc_order", 7)

    if not user or level_id is None:
        return jsonify({"error": "Missing user or level_id"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "User not found"}), 404

    database.set_user_field(user, "checkpoint", level_id)

    # ★ 记录"到过遇境(CandleSpace / SkyHub2)"：客户端进入遇境时上报 level_id
    #   3526133726（CandleSpace）或 2825107789（SkyHub2，同图别名）。
    #   一旦到过，之后登录一律出生在遇境（见 get_checkpoints）
    HOME_LEVEL_ID = 3526133726  # FNV-1a("CandleSpace")
    SKY_HUB2_LEVEL_ID = 2825107789  # FNV-1a("SkyHub2")，与 CandleSpace 同地图
    try:
        if int(level_id) in (HOME_LEVEL_ID, SKY_HUB2_LEVEL_ID):
            database.set_user_field(user, "visited_home", 1)
    except (TypeError, ValueError):
        pass

    return jsonify({
        "checkpoints": [
            {
                "user": user,
                "level_id": level_id,
                "level_hash": level_hash,
                "bst_id": bst_id,
                "states": states,
                "is_furthest": True,
                "arc_order": arc_order
            }
        ]
    })

@account_bp.route("/set_outfit", methods=["POST"])
def set_outfit():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    outfit = req.get("outfit", {})

    if not user or not outfit:
        return jsonify({"error": "missing user or outfit"}), 400

    fields = {
        "outfit_body": outfit.get("body", {}).get("id", 0),
        "outfit_wing": outfit.get("wing", {}).get("id", 0),
        "outfit_hair": outfit.get("hair", {}).get("id", 0),
        "outfit_mask": outfit.get("mask", {}).get("id", 0),
        "outfit_neck": outfit.get("neck", {}).get("id", 0),
        "outfit_feet": outfit.get("feet", {}).get("id", 0),
        "outfit_horn": outfit.get("horn", {}).get("id", 0),
        "outfit_arms": outfit.get("arms", {}).get("id", 0),
        "outfit_prop": outfit.get("prop", {}).get("id", 0),
        # ★ 修复：以前 hat / face 被写死成 0，玩家换的帽子和面具永远存不住
        "outfit_hat": outfit.get("hat", {}).get("id", 0),
        "outfit_face": outfit.get("face", {}).get("id", 0),
        "outfit_height": outfit.get("height", 0)
    }

    if not database.user_exists(user):
        return jsonify({"error": "user not found"}), 404

    database.execute(
        "UPDATE users SET " +
        ", ".join([f"{k}=?" for k in fields]) +
        " WHERE id=?",
        (*fields.values(), user)
    )

    row = database.query_one(
        "SELECT outfit_wing, outfit_prop, outfit_face, outfit_mask, "
        "outfit_hair, outfit_body, outfit_arms, outfit_feet, "
        "outfit_hat, outfit_horn, outfit_neck, outfit_height "
        "FROM users WHERE id = ?", (user,)
    )

    # ★ 面板「设置」里的身高 / 大小优先于客户端本次传来的值（**都要夹紧到客户端合法区间**）
    _p = _get_prefs(user)
    _ph = _clamp_h(_float_or_none(_p.get("height")))
    _ps = _clamp_h(_float_or_none(_p.get("scale")), -3.0, 3.0)

    return jsonify({
        "result": "ok",
        "set_outfit": _clean_outfit({
            "wing": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_wing"]},
            "voice": 0,
            "seed": 37061,
            "scale": _clamp_h(_ps if _ps is not None else outfit.get("scale", 0.009), -3.0, 3.0),
            "prop": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_prop"]},
            "neck": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_neck"]},
            "mask": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_mask"]},
            "horn": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_horn"]},
            "height": _clamp_h(_ph if _ph is not None else row["outfit_height"]),
            "hat": {"id": row["outfit_hat"]},
            "hair": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_hair"]},
            "feet": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_feet"]},
            "face": {"id": row["outfit_face"]},
            "body": {"tex": 0, "pat": 0, "mask": 0, "id": row["outfit_body"]},
            "attitude": str(outfit.get("attitude", 0)),
        })
    })

@account_bp.route("/get_relationship_abilities", methods=["POST"])
def get_relationship_abilities():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='relationship_abilities.json',
        mimetype='application/json'
    )

@account_bp.route("/iaplist", methods=["POST"])
def iap_list():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='iaplist.json',
        mimetype='application/json'
    )

@account_bp.route("/get_invites", methods=["POST"])
def get_invites():
    """客户端周期性拉取"待接受的好友邀请"。

    ★ 2026-10-03：以前这里写死返回 {"invites": []} —— 真机请求记录里
      `POST /account/get_invites {"user":…,"session":…}` 一直在轮询，永远拿到空表，
      所以"接受好友"入口只能靠礼物消息兜。现在读 pending_invites 表
      （与 /check_invite 同一份数据），并多给几种键名拼写以防猜错。
    """
    req = request.get_json(force=True, silent=True) or {}
    me = _req_user(req)
    invites = []
    if me:
        try:
            for r in database.query_all(
                    # ★ 列名是 `nickname`（见 db.py 的建表语句），不是 invite_nickname ——
                    #   写错会导致 OperationalError(1054) 被吞掉 → 永远返回空邀请列表
                    #   → 真机表现就是「接受好友点了没反应」。
                    "SELECT token_id, from_user, nickname, level_id, created_at, status "
                    "FROM pending_invites WHERE to_user = ? AND status = 'pending' "
                    "ORDER BY created_at DESC LIMIT 50", (me,)):
                invites.append({
                    "token_id": r.get("token_id"), "token": r.get("token_id"),
                    "from_user": r.get("from_user"), "user": r.get("from_user"),
                    "invite_nickname": r.get("nickname") or "",
                    "nickname": r.get("nickname") or "",
                    "level_id": r.get("level_id") or 0,
                    "created_at": r.get("created_at") or 0,
                    "status": "pending",
                })
        except Exception as e:
            _social_log("get_invites.err", repr(e))
    if invites:
        _social_log("get_invites", {"user": me, "count": len(invites)})
    return jsonify({"result": "ok", "status": "ok", "ok": True,
                    "invites": invites, "count": len(invites),
                    "set_invites": invites})

@account_bp.route("/buff/get_buff_defs", methods=["POST"])
def get_buff_defs():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='buff_defs.json',
        mimetype='application/json'
    )

@account_bp.route("/get_generic_shops", methods=["POST"])
def get_generic_shops():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='generic_shops.json',
        mimetype='application/json'
    )

@account_bp.route("/set_achievement_stats", methods=["POST"])
def set_achievement_stats():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    stats = req.get("achievement_stats", [])

    if not user or not isinstance(stats, list):
        return jsonify({"error": "invalid payload"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "user not found"}), 404

    raw_data = database.get_user_field(user, "achievements")
    old = json.loads(raw_data) if raw_data else []

    now = int(datetime.utcnow().timestamp())
    merged = {item["type"]: item for item in old}
    for st in stats:
        tp, val = st["type"], st["value"]
        if tp in merged:
            merged[tp]["value"] += val
            merged[tp]["update"] = now
        else:
            merged[tp] = {"type": tp, "value": val, "update": now}

    new_list = list(merged.values())
    database.set_user_field(user, "achievements", json.dumps(new_list))

    return jsonify({
        "achievement_stats": [
            {"type": i["type"], "value": i["value"], "update": i["update"]}
            for i in new_list
        ]
    })

# 空白返回区
@account_bp.route("/drop_unlock", methods=["POST"])
def drop_unlock():
    return jsonify({}), 200

@account_bp.route("/geonote/get_user_geonotes", methods=["POST"])
def get_user_geonotes():
    return jsonify({}), 200

@account_bp.route("/geonote/request_geonotes_for_n_friends", methods=["POST"])
def request_geonotes_for_n_friends():
    return jsonify({}), 200

@account_bp.route("/collect_pickup_batch", methods=["POST"])
def collect_pickup_batch():
    return jsonify({}), 200

@account_bp.route("/social_feed/get_user_feeds", methods=["POST"])
def get_user_feeds():
    return jsonify({
        "pool_type": "SeasonMeditationShrineNormal",
        "pool_name": "meditate_prairie_butterfly_pool",
        "message": "This a first Feeds Candle in this server by yunjian"
    }), 200

@account_bp.route("/social_feed/get_curated_feeds", methods=["POST"])
def get_curated_feeds():
    return jsonify({
        "pool_type": "SeasonMeditationShrineNormal",
        "pool_name": "meditate_prairie_butterfly_pool",
        "message": "This a first Feeds Candle in this server by yunjian"
    }), 200

@account_bp.route("/get_season_quests", methods=["POST"])
def get_season_quests():
    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "season_quests.json")
    if not os.path.isfile(cfg_path):
        return jsonify({"error": "config not found"}), 404

    with open(cfg_path, encoding="utf-8") as f:
        data = json.load(f)

    today = datetime.utcnow().strftime("%Y-%m-%d")

    for key in ("season_quests", "has_season_quests_rewards"):
        for obj in data.get(key, []):
            if "daily_quest_def_id" in obj:
                obj["data"] = today

    return jsonify(data)

@account_bp.route("/activate_season_quest", methods=["POST"])
def activate_season_quests():
    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "season_quests.json")
    if not os.path.isfile(cfg_path):
        return jsonify({"error": "config not found"}), 404

    with open(cfg_path, encoding="utf-8") as f:
        data = json.load(f)

    today = datetime.utcnow().strftime("%Y-%m-%d")

    for key in ("season_quests", "has_season_quests_rewards"):
        for obj in data.get(key, []):
            if "daily_quest_def_id" in obj:
                obj["data"] = today

    return jsonify(data)

@account_bp.route("/claim_season_quest_reward", methods=["POST"])
def claim_season_quest_reward():
    return jsonify({})

@account_bp.route("/social_feed/create", methods=["POST"])
def create_feed():
    with open('unlock.log.txt', 'a', encoding='utf-8') as f:
        f.write(f'[{datetime.utcnow().isoformat()}Z]\n')
        f.write(f'{request.method} {request.full_path} {request.environ.get("SERVER_PROTOCOL")}\n')
        for k, v in request.headers.items():
            f.write(f'{k}: {v}\n')
        f.write('\n')
        body = request.get_data(as_text=True)
        f.write(body + '\n')
        f.write('-' * 60 + '\n')
    return jsonify({})

@account_bp.route("/wing_buffs/collect", methods=["POST"])
def collect_wing_buffs():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    names = req.get("names", [])

    if not user or not isinstance(names, list):
        return jsonify({"error": "invalid payload"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "user not found"}), 404

    raw_data = database.get_user_field(user, "wing_buffs")
    old = json.loads(raw_data) if raw_data else []

    new_buffs = list(set(old + names))
    database.set_user_field(user, "wing_buffs", json.dumps(new_buffs))

    update_list = [{"name": n, "collected": True} for n in names]
    return jsonify({
        "result": "ok",
        "update_wing_buffs": update_list
    })

@account_bp.route("/purchase_unlock", methods=["POST"])
def purchase_unlock():
    # 始终返回完整的内购解锁列表，所有物品均已解锁
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='all_purchase_unlock.json',
        mimetype='application/json'
    )

# ---------- 解锁确认接口 ----------
@account_bp.route("/ack_unlock", methods=["POST"])
def ack_unlock():
    """解锁确认接口 - 客户端调用此接口确认已收到解锁状态"""
    return jsonify({"result": "ok"})

# ---------- 缺失的 API 端点补充 ----------
# 以下端点在 resource_list 中声明但原代码未实现，补充空返回以避免 404

@account_bp.route("/get_map_defs", methods=["POST"])
def get_map_defs():
    return jsonify({"map_defs": []})

@account_bp.route("/get_status_unlocks", methods=["POST"])
def get_status_unlocks():
    """获取状态解锁列表 - 包含所有内购和关卡解锁"""
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='all_unlock_status.json',
        mimetype='application/json'
    )

@account_bp.route("/get_free_gifts", methods=["POST"])
def get_free_gifts():
    return jsonify({"free_gifts": []})

@account_bp.route("/get_achievement_defs", methods=["POST"])
def get_achievement_defs():
    return jsonify({"achievement_defs": []})

@account_bp.route("/get_achievement_stats_tracking", methods=["POST"])
def get_achievement_stats_tracking():
    return jsonify({"achievement_stats_tracking": []})

@account_bp.route("/get_event_currency_defs", methods=["POST"])
def get_event_currency_defs():
    return jsonify({"event_currency_defs": []})

@account_bp.route("/get_consumable_defs", methods=["POST"])
def get_consumable_defs():
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='consumable_defs.json',
        mimetype='application/json'
    )

@account_bp.route("/get_infractions", methods=["POST"])
def get_infractions():
    return jsonify({"infractions": []})

# ---------- 聊天/消息相关端点补充 ----------
# 说明：光遇「同一张地图内」的实时聊天走的是 UDP（ENet）通道，
# 由 udp_relay_enet.py 负责转发，不经过这里。
# 下面这些 HTTP 端点只是客户端可能调用的兼容桩。
# 为了便于排查「聊天到底走的哪条路」，这里会把请求体写到 logs/chat.log。

def _log_chat(endpoint):
    try:
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
        os.makedirs(log_dir, exist_ok=True)
        body = request.get_json(force=True, silent=True)
        if body is None:
            body = request.get_data(as_text=True)
        with open(os.path.join(log_dir, "chat.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.utcnow().isoformat()}Z {endpoint} {request.host}\n")
            f.write(json.dumps(body, ensure_ascii=False)[:2000] + "\n")
            f.write("-" * 60 + "\n")
    except Exception:
        pass


@account_bp.route("/get_messages", methods=["POST"])
def get_messages():
    """获取消息列表 - 用于聊天历史同步"""
    _log_chat("get_messages")
    return jsonify({"messages": []})

@account_bp.route("/gift_messages/get", methods=["POST"])
def get_gift_messages():
    """获取礼物消息"""
    return jsonify({"gift_messages": []})

@account_bp.route("/message_chat/get", methods=["POST"])
def get_message_chat():
    """聊天消息获取端点"""
    _log_chat("message_chat/get")
    return jsonify({"message_chats": []})

@account_bp.route("/message_chat/send", methods=["POST"])
def send_message_chat():
    """聊天消息发送端点 - 实时聊天主要走 UDP，这里返回成功确认"""
    _log_chat("message_chat/send")
    return jsonify({"result": "ok"})

@account_bp.route("/chat/join", methods=["POST"])
def chat_join():
    """加入聊天室"""
    return jsonify({"result": "ok"})

@account_bp.route("/chat/leave", methods=["POST"])
def chat_leave():
    """离开聊天室"""
    return jsonify({"result": "ok"})

# ---------- 缺失接口补充（0.15.5 兼容） ----------

@account_bp.route("/get_outfit_defs", methods=["POST"])
def get_outfit_defs():
    """装扮定义目录（2.1MB）。

    ★★★ 2026-10-03 第二修：**服务端这两份表，客户端一份都不认**。
      客户端的装扮表是它**自带的 APK 资源** `assets/Data/Resources/OutfitDefs.json`
      （432 条 / `mesh` 是数组 / 键名 `color_hsv|pattern_hsv|tint_hsv|iconName|
       skipMotionBlur|putBackAnimSeq|disableBody|isSkyKid…`）；
      而 `config/outfit_defs.json` 是**另一套 schema**（`mesh` 是字符串、
      键名 `attribTex|diffuseTex|inCloset|base_hsv|icon_hsv|dyeable_primary…`）。
      判据：`.so` 里搜 `outfit_defs` / `get_outfit_defs` **都不存在**
      ⇒ 客户端**从不调用**本接口；`0x1042900~0x1042a84` 那一整片连续字段名
      **只对得上 APK 那份**，我们那 16 个独有键在 .so 里只命中 1 个。

      ⇒ 按用户建议，把**客户端自己那份 JSON 原样放到服务端**并在这里下发
        （`config/outfit_defs_client.json`，schema 与客户端完全一致）。
        这样即使将来某个版本真来读，也一定解析得动。
    """
    cfg_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")
    client_path = os.path.join(cfg_dir, "outfit_defs_client.json")
    if os.path.isfile(client_path):
        try:
            with open(client_path, encoding="utf-8") as f:
                defs = json.load(f)
            return jsonify({"outfit_defs": defs})
        except Exception as e:
            _social_log("get_outfit_defs.client.err", repr(e))
    return send_from_directory(
        directory=cfg_dir,
        path='outfit_defs.json',
        mimetype='application/json'
    )

@account_bp.route("/get_relationship_defs", methods=["POST"])
def get_relationship_defs():
    """关系定义 - 客户端需要此接口加载社交关系树"""
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='relationship_abilities.json',
        mimetype='application/json'
    )

@account_bp.route("/get_star_tag_defs", methods=["POST"])
def get_star_tag_defs():
    """星标定义"""
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='stars_config.json',
        mimetype='application/json'
    )

# ---------- 好友状态/在线相关端点 ----------

@account_bp.route("/set_friend_status", methods=["POST"])
def set_friend_status():
    """设置好友状态"""
    return jsonify({"result": "ok"})

@account_bp.route("/set_random", methods=["POST"])
def set_random():
    """随机匹配相关"""
    return jsonify({"set_random": []})

@account_bp.route("/hb", methods=["POST"])
def heartbeat():
    """心跳检测接口"""
    return jsonify({
        "status": "ok",
        "timestamp": int(time.time()),
        "server_time": datetime.utcnow().isoformat() + "Z"
    })

# ---------- 0.15.5 额外兼容端点 ----------

@account_bp.route("/get_outfit_wards", methods=["POST"])
def get_outfit_wards():
    return jsonify({"outfit_wards": []})

@account_bp.route("/get_traveling_spirits", methods=["POST"])
def get_traveling_spirits():
    return jsonify({"traveling_spirits": []})

@account_bp.route("/get_season_pass_defs", methods=["POST"])
def get_season_pass_defs():
    return jsonify({"season_pass_defs": []})

@account_bp.route("/get_quest_defs", methods=["POST"])
def get_quest_defs():
    return jsonify({"quest_defs": []})

@account_bp.route("/get_weekly_quests", methods=["POST"])
def get_weekly_quests():
    return jsonify({"weekly_quests": []})

@account_bp.route("/get_daily_quests", methods=["POST"])
def get_daily_quests():
    return jsonify({"daily_quests": []})

@account_bp.route("/get_currency_defs", methods=["POST"])
def get_currency_defs():
    return jsonify({"currency_defs": []})

@account_bp.route("/get_bundle_defs", methods=["POST"])
def get_bundle_defs():
    return jsonify({"bundle_defs": []})

@account_bp.route("/get_season_quests_v2", methods=["POST"])
def get_season_quests_v2():
    return jsonify({"season_quests": [], "has_season_quests_rewards": []})

@account_bp.route("/get_spirit_memory_defs", methods=["POST"])
def get_spirit_memory_defs():
    return jsonify({"spirit_memory_defs": []})

@account_bp.route("/get_event_currency", methods=["POST"])
def get_event_currency():
    return jsonify({"event_currency": []})

@account_bp.route("/get_social_card_defs", methods=["POST"])
def get_social_card_defs():
    return jsonify({"social_card_defs": []})

# ============================================================
# ★★ 2026-10-03 新增：社交链路（加好友邀请 / 给蜡烛 / 礼物消息）
#
# 为什么会有这一段：客户端 libBootloader.so 的字符串表里明确有这些接口
#   /account/give_candle      (keys: /recv_user /ability_id /ability_cost /pos /level_id)
#   /account/create_invite    (key : /invite_nickname)
#   /account/delete_invite    (key : /token_id)
#   /account/check_invite     ← 对方拉取"待接受邀请"，接受按钮就是它给的
#   /account/accept_invite
#   account/send_message      (keys: /target /gift_type)
#   account/claim_message_gift(key : /msg_id)
#   /account/get_pending_messages (回包: set_recvd_messages / set_sent_messages)
#   AccountGiftMessage 的字段: recvd / from_id / from_currency_type /
#                              from_currency_count / to_id / to_currency_type /
#                              to_currency_count / raw_message
# 这些接口我们**一个都没实现**，以前全被 catch-all 兜成 `{}`
# ⇒ 现象就是「给蜡烛之后，对方那一边永远不出现接受按钮」。
#
# 实现上做了两层保险：
#   ① 字段名兼容多种拼写（user/user_id/…、recv_user/target/…），万一我猜的键名和
#      客户端实际用的不完全一致也能吃下去；
#   ② config.json 打开 log_requests 后，logs/requests.log 会记下每个请求的原始 body，
#      真机跑一次就能把真实字段名核准、再收紧。
# ============================================================

_SOCIAL_LOG = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'social.log')


def _social_log(tag, payload):
    """社交接口留痕（本身就是排障要用的，量很小，一直开着）。"""
    try:
        os.makedirs(os.path.dirname(_SOCIAL_LOG), exist_ok=True)
        with open(_SOCIAL_LOG, 'a', encoding='utf-8') as f:
            f.write("%s %s %s\n" % (datetime.utcnow().isoformat() + 'Z', tag,
                                    json.dumps(payload, ensure_ascii=False)[:2000]))
    except Exception:
        pass


def _pick_any(req, *names):
    """从请求体里按多个候选键名取第一个非空值。"""
    for n in names:
        if isinstance(req, dict) and n in req:
            v = req[n]
            if v not in (None, "", []):
                return v
    return None


def _req_user(req):
    return _pick_any(req, "user", "user_id", "account", "from_user", "sender", "id")


def _req_target(req):
    return _pick_any(req, "recv_user", "target", "to_user", "to_id", "friend",
                     "friend_id", "other_user")


def _now():
    return int(time.time())


def _load_cfg_safe():
    try:
        return load_config()
    except Exception:
        return {}


@account_bp.route("/create_invite", methods=["POST"])
def create_invite():
    """发起"加好友"邀请（给对方发一个待接受邀请 + 昵称）。"""
    req = request.get_json(force=True, silent=True) or {}
    _social_log("create_invite.req", req)
    me = _req_user(req)
    if not me:
        return jsonify({"result": "error", "error": "missing user",
                        "status": "error", "ok": False}), 400
    target = _req_target(req)
    nick = _pick_any(req, "invite_nickname", "nickname", "name", "friend_name") or ""
    token = str(uuid.uuid4())
    try:
        database.execute(
            "INSERT INTO pending_invites (token_id, from_user, to_user, nickname, "
            "level_id, created_at, status) VALUES (?,?,?,?,?,?,?)",
            (token, me, target or "", str(nick)[:190],
             int(_pick_any(req, "level_id", "level") or 0), _now(), "pending"))
    except Exception as e:
        _social_log("create_invite.err", repr(e))
    resp = {"result": "ok", "status": "ok", "ok": True,
            "token_id": token, "token": token,
            "invite_nickname": str(nick)}
    _social_log("create_invite.resp", resp)
    return jsonify(resp)


@account_bp.route("/check_invite", methods=["POST"])
def check_invite():
    """对方拉取"发给我的待接受邀请" —— 客户端据此弹出接受按钮。"""
    req = request.get_json(force=True, silent=True) or {}
    me = _req_user(req)
    _social_log("check_invite.req", {"user": me})
    rows = []
    if me:
        try:
            rows = database.query_all(
                "SELECT token_id, from_user, nickname, level_id, created_at FROM pending_invites "
                "WHERE to_user = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 50", (me,))
        except Exception as e:
            _social_log("check_invite.err", repr(e))

    invites = []
    for r in rows or []:
        invites.append({
            "token_id": r.get("token_id"),
            "token": r.get("token_id"),
            "from_user": r.get("from_user"),
            "user": r.get("from_user"),
            "invite_nickname": r.get("nickname", ""),
            "nickname": r.get("nickname", ""),
            "level_id": r.get("level_id", 0),
            "created_at": r.get("created_at", 0),
            "status": "pending",
        })
    resp = {"result": "ok", "status": "ok", "ok": True,
            "invite_count": len(invites),
            "invites": invites, "set_invites": invites, "pending_invites": invites}
    _social_log("check_invite.resp", {"count": len(invites), "invites": invites})
    return jsonify(resp)


@account_bp.route("/accept_invite", methods=["POST"])
def accept_invite():
    """接受邀请 → 双方互为好友（写入 friends 表，get_friends 会读它）。"""
    req = request.get_json(force=True, silent=True) or {}
    _social_log("accept_invite.req", req)
    me = _req_user(req)
    token = _pick_any(req, "token_id", "token")
    inviter = _pick_any(req, "from_user", "sender")
    nick = _pick_any(req, "invite_nickname", "nickname") or ""

    mine_nick = nick
    if token and not inviter:
        try:
            row = database.query_one(
                "SELECT from_user, nickname FROM pending_invites WHERE token_id = ?", (token,))
            if row:
                inviter = row.get("from_user")
                if not mine_nick:
                    mine_nick = row.get("nickname", "")
        except Exception as e:
            _social_log("accept_invite.err", repr(e))

    if me and inviter:
        for a, b in ((me, inviter), (inviter, me)):
            try:
                exists = database.query_one(
                    "SELECT COUNT(*) AS cnt FROM friends WHERE user_id = ? AND friend_id = ?",
                    (a, b))
                if not exists or exists.get("cnt") == 0:
                    database.execute(
                        "INSERT INTO friends (user_id, friend_id, nickname, level, created_at) "
                        "VALUES (?,?,?,?,?)", (a, b, str(mine_nick)[:190], 1, _now()))
            except Exception as e:
                _social_log("accept_invite.err2", repr(e))
    if token:
        try:
            database.execute("UPDATE pending_invites SET status = 'accepted' WHERE token_id = ?",
                             (token,))
        except Exception:
            pass
    if me and inviter:
        try:
            database.execute("UPDATE pending_invites SET status = 'accepted' "
                             "WHERE from_user = ? AND to_user = ?", (inviter, me))
        except Exception:
            pass
    resp = {"result": "ok", "status": "ok", "ok": True, "friend": inviter or ""}
    _social_log("accept_invite.resp", resp)
    return jsonify(resp)


@account_bp.route("/delete_invite", methods=["POST"])
def delete_invite():
    req = request.get_json(force=True, silent=True) or {}
    _social_log("delete_invite.req", req)
    token = _pick_any(req, "token_id", "token")
    if token:
        try:
            database.execute("UPDATE pending_invites SET status = 'deleted' WHERE token_id = ?",
                             (token,))
        except Exception:
            pass
    return jsonify({"result": "ok", "status": "ok", "ok": True})


def _ensure_friendship(a, b):
    """双向建立好友关系（幂等）。

    ★★★ 2026-10-03：这是「给蜡烛一直被退回」的直接原因。
      真机时间轴：`cd4a2333 --give_candle--> 5f4d56b3` 在 06:05:57 / 06:06:09 /
      06:06:21 / 06:06:30 **每 10 秒重发一次**，说明发起方始终没拿到"关系已建立"
      的确认。而客户端判定"是不是好友"的唯一来源是 `/account/get_friends`
      的 `set_friends` —— 我们之前只往 gift_messages 写了一条礼物，**从来没写
      friends 表**，所以双方永远不是好友 ⇒ 客户端认为这次给蜡烛没被接受 ⇒
      蜡烛退回 + 无限重试。
    """
    if not a or not b or a == b:
        return
    now = _now()
    for u, f in ((a, b), (b, a)):
        try:
            if database.query_one(
                    "SELECT user_id FROM friends WHERE user_id = ? AND friend_id = ?",
                    (u, f)):
                continue
            nick = ""
            try:
                raw = database.get_user_field(f, "nickname")
                nick = str(raw or "")[:190]
            except Exception:
                nick = ""
            database.execute(
                "INSERT INTO friends (user_id, friend_id, nickname, level, created_at) "
                "VALUES (?,?,?,?,?)", (u, f, nick, 0, now))
        except Exception as e:
            _social_log("friendship.err", repr(e))


@account_bp.route("/give_candle", methods=["POST"])
def give_candle():
    """给蜡烛（升级好友关系 / 送礼）。

    客户端字段：/recv_user /ability_id /ability_cost /pos /level_id。
    我们落成一条"待对方领取的礼物消息"，对方用 get_pending_messages 拉到、
    client 就会在界面上给出接受/领取入口。
    """
    req = request.get_json(force=True, silent=True) or {}
    _social_log("give_candle.req", req)
    me = _req_user(req)
    target = _req_target(req)
    cost = _pick_any(req, "ability_cost", "cost", "count", "currency_count")
    try:
        cost = int(cost or 0)
    except (TypeError, ValueError):
        cost = 0
    ability = _pick_any(req, "ability_id", "ability") or 0
    msg_id = str(uuid.uuid4())
    if me and target:
        try:
            database.execute(
                "INSERT INTO gift_messages (msg_id, from_user, to_user, gift_type, "
                "currency_type, currency_count, raw_message, sent_at, claimed) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (msg_id, me, target, int(_pick_any(req, "gift_type") or 0), 1, cost,
                 str(ability)[:250], _now(), 0))
        except Exception as e:
            _social_log("give_candle.err", repr(e))
        # ★★★ 好友关系只在**双方互相递过蜡烛**时建立（2026-10-03 真机实证）。
        #   客户端侧的「递蜡烛」是游戏内的 PremiumCandle offer/accept RPC 交互，
        #   真机日志：`PremiumCandle: Start offer remote` → 0.7 秒后 `Cancelled remotely`。
        #   上一版我让**单方面**递一次蜡烛就写好友关系 ⇒ 对面客户端一查
        #   `/account/get_friends` 发现"已经是好友"⇒ 把这个 offer 判成无效并**主动取消**
        #   ⇒ 关系节点永远解锁不了 ⇒ 好友树里看不到这个人。
        #   ⇒ 正确规则：只记录礼物；发现**对方也递过我蜡烛**（双向）才写双向好友关系。
        reciprocal = False
        try:
            reciprocal = bool(database.query_one(
                "SELECT msg_id FROM gift_messages WHERE from_user = ? AND to_user = ? LIMIT 1",
                (target, me)))
        except Exception as e:
            _social_log("give_candle.reciprocal.err", repr(e))
        if reciprocal:
            _ensure_friendship(me, target)
            try:
                database.execute(
                    "UPDATE gift_messages SET claimed = 1 "
                    "WHERE from_user = ? AND to_user = ? AND claimed = 0", (target, me))
                database.execute(
                    "UPDATE gift_messages SET claimed = 1 "
                    "WHERE from_user = ? AND to_user = ? AND claimed = 0", (me, target))
            except Exception as e:
                _social_log("give_candle.claim.err", repr(e))
    resp = {"result": "ok", "status": "ok", "ok": True, "msg_id": msg_id,
            "ability_id": ability, "ability_cost": cost,
            "friend_id": target or "", "target": target or "",
            "relationship": {"user": target or "", "friend": target or "",
                             "ability_id": ability, "unlocked": True}}
    _social_log("give_candle.resp", resp)
    return jsonify(resp)


@account_bp.route("/send_message", methods=["POST"])
def send_message():
    """送礼消息（客户端字符串表里是 account/send_message，键 /target /gift_type）。"""
    req = request.get_json(force=True, silent=True) or {}
    _social_log("send_message.req", req)
    me = _req_user(req)
    target = _req_target(req)
    gift_type = _pick_any(req, "gift_type", "gift") or 0
    count = _pick_any(req, "currency_count", "count", "gift_count")
    try:
        count = int(count or 0)
    except (TypeError, ValueError):
        count = 0
    msg_id = str(uuid.uuid4())
    if me and target:
        try:
            database.execute(
                "INSERT INTO gift_messages (msg_id, from_user, to_user, gift_type, "
                "currency_type, currency_count, raw_message, sent_at, claimed) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (msg_id, me, target, int(gift_type or 0), 0, count,
                 str(_pick_any(req, "raw_message", "text", "message") or "")[:250],
                 _now(), 0))
        except Exception as e:
            _social_log("send_message.err", repr(e))
    return jsonify({"result": "ok", "status": "ok", "ok": True, "msg_id": msg_id})


def _gift_entry(r, recvd):
    """把 gift_messages 一行转成客户端 AccountGiftMessage 期望的字段集合。

    字段名来自 libBootloader.so 的 AccountGiftMessage 字符串簇：
      recvd / from_id / from_currency_type / from_currency_count /
      to_id / to_currency_type / to_currency_count / raw_message
    """
    cur_t = r.get("currency_type", 0)
    cur_c = r.get("currency_count", 0)
    return {
        "msg_id": r.get("msg_id"),
        "recvd": bool(recvd),
        "from_id": r.get("from_user"),
        "from_user": r.get("from_user"),
        "to_id": r.get("to_user"),
        "to_user": r.get("to_user"),
        "gift_type": r.get("gift_type", 0),
        "from_currency_type": cur_t,
        "from_currency_count": cur_c,
        "to_currency_type": cur_t,
        "to_currency_count": cur_c,
        # ★ 客户端 AccountGiftMessage 里有一组 types（`!types && typeCount == 0` 断言），
        #   一份礼物可能带多种货币；不给它 → 解析失败（真机日志：
        #   "Failed to parse resource sync response of AccountGiftMessageResource
        #    for syncAction sent_message"）→ 接受流程走不下去、蜡烛被退回。
        "types": [{"type": cur_t, "count": cur_c, "currency_type": cur_t, "currency_count": cur_c}],
        "type_count": 1,
        "raw_message": r.get("raw_message", ""),
        "sent_at": r.get("sent_at", 0),
        "claimed": r.get("claimed", 0),
    }


# 注意：/account/get_pending_messages 的**唯一**实现在文件上半部分
# （原来发静态 pending.json 的那个），这里不再重复定义 —— 同名视图函数会让
# Flask 在 register_blueprint 时抛
#   AssertionError: View function mapping is overwriting an existing endpoint function
# 直接导致容器起不来。2026-10-03 踩过一次，别再犯。


@account_bp.route("/claim_message_gift", methods=["POST"])
def claim_message_gift():
    """领取礼物消息（键 /msg_id）：标记已领并把蜡烛/爱心加给领取人。"""
    req = request.get_json(force=True, silent=True) or {}
    _social_log("claim_message_gift.req", req)
    me = _req_user(req)
    msg_id = _pick_any(req, "msg_id", "id")
    row = None
    if msg_id:
        try:
            row = database.query_one(
                "SELECT msg_id, from_user, to_user, currency_type, currency_count, claimed "
                "FROM gift_messages WHERE msg_id = ?", (msg_id,))
        except Exception as e:
            _social_log("claim_message_gift.err", repr(e))
    if row and not row.get("claimed"):
        try:
            database.execute("UPDATE gift_messages SET claimed = 1 WHERE msg_id = ?", (msg_id,))
            cnt = int(row.get("currency_count") or 0)
            if me and cnt > 0:
                cur = database.get_user_field(me, "candles")
                try:
                    cur = int(cur or 0)
                except (TypeError, ValueError):
                    cur = 0
                database.set_user_field(me, "candles", cur + cnt)
        except Exception as e:
            _social_log("claim_message_gift.err2", repr(e))
    return jsonify({"result": "ok", "status": "ok", "ok": True, "msg_id": msg_id})


# ---------- Catch-All 兜底路由 ----------
# 任何未匹配的 /account/ POST 请求都返回空 JSON，避免 404 导致按钮消失

@account_bp.route("/", defaults={"path": ""}, methods=["POST", "GET"])
@account_bp.route("/<path:path>", methods=["POST", "GET"])
def account_catch_all(path):
    """兜底路由：未实现的 /account/ 接口返回空 JSON，避免客户端按钮消失"""
    return jsonify({}), 200