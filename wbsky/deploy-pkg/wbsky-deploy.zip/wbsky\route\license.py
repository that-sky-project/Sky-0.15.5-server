# route/license.py
# ============================================================
# 鼓启私服 —— 卡密（激活码）系统
#
#  客户端： POST /key/verify     { key, device_id, pkg, ver }
#  管理端： GET  /admin          卡密管理页面（sky.gvqi.top/admin）
#           POST /admin/api/login
#           GET  /admin/api/list
#           POST /admin/api/create
#           POST /admin/api/action
#
# 设计要点
#   - 卡密一次性绑定设备（首次激活时绑定 Android ID），换机需要管理端解绑
#   - duration_h = 0 表示永久卡；否则从【首次激活】开始计时（不是从生成时间）
#   - status: unused / active / expired / disabled
#   - config.json 里 "license_enabled": false 可一键关闭校验（应急开关）
# ============================================================

import json
import os
import sys
import time
import secrets
import threading

from flask import Blueprint, request, jsonify, send_from_directory

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import db as database

license_bp = Blueprint('license', __name__)

_ROOT = os.path.dirname(os.path.dirname(__file__))       # /app
_WEB_DIR = os.path.join(_ROOT, 'web')
_CONFIG_PATH = os.path.join(_ROOT, 'config.json')
_LOG_DIR = os.path.join(_ROOT, 'logs')

# 去掉容易看错的 0/O/1/I/L
KEY_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'
KEY_LEN = 16
KEY_GROUP = 4

_TOKENS = {}
_TOKEN_TTL = 12 * 3600
_LOCK = threading.Lock()

DEFAULT_ADMIN_PASSWORD = 'guqi114514'


# ---------------------------------------------------------------- 基础工具

def load_config():
    try:
        with open(_CONFIG_PATH, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _now():
    return int(time.time())


def _norm_key(s):
    """把用户输入的卡密归一化：只保留字母数字并大写"""
    if not s:
        return ''
    return ''.join(ch for ch in str(s).upper() if ch.isalnum())


def _fmt_key(raw):
    """ABCDEFGH... -> ABCD-EFGH-..."
    """
    raw = _norm_key(raw)
    return '-'.join(raw[i:i + KEY_GROUP] for i in range(0, len(raw), KEY_GROUP))


def _gen_key():
    body = ''.join(secrets.choice(KEY_ALPHABET) for _ in range(KEY_LEN))
    return _fmt_key(body)


def _status_of(row, now=None):
    now = now or _now()
    st = (row.get('status') or 'unused')
    if st == 'disabled':
        return 'disabled'
    if st == 'unbound':
        return 'unbound'
    exp = int(row.get('expire_at') or 0)
    if exp and now > exp:
        return 'expired'
    if int(row.get('activated_at') or 0):
        return 'active'
    return 'unused'


def _log(action, detail):
    try:
        os.makedirs(_LOG_DIR, exist_ok=True)
        line = '%s\t%s\t%s\t%s\n' % (
            time.strftime('%Y-%m-%d %H:%M:%S'), action,
            detail, request.headers.get('X-Forwarded-For', request.remote_addr or ''))
        with open(os.path.join(_LOG_DIR, 'license.log'), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass


# ---------------------------------------------------------------- 管理端鉴权

def _admin_password():
    cfg = load_config()
    return str(cfg.get('admin_password') or DEFAULT_ADMIN_PASSWORD)


def _check_token():
    tok = (request.headers.get('X-Admin-Token')
           or request.args.get('token')
           or (request.get_json(silent=True) or {}).get('token')
           or '')
    if not tok:
        return False
    with _LOCK:
        exp = _TOKENS.get(tok)
        if not exp:
            return False
        if exp < _now():
            _TOKENS.pop(tok, None)
            return False
    return True


def _deny():
    return jsonify({'ok': False, 'msg': '登录已失效，请重新登录'}), 401


# ---------------------------------------------------------------- 管理端接口

@license_bp.route('/admin', methods=['GET'])
def admin_page():
    return send_from_directory(_WEB_DIR, 'admin.html')


@license_bp.route('/admin/api/login', methods=['POST'])
def admin_login():
    req = request.get_json(force=True, silent=True) or {}
    if str(req.get('password') or '') != _admin_password():
        _log('LOGIN-FAIL', '密码错误')
        return jsonify({'ok': False, 'msg': '密码错误'}), 200
    tok = secrets.token_urlsafe(24)
    with _LOCK:
        _TOKENS[tok] = _now() + _TOKEN_TTL
    _log('LOGIN-OK', '')
    return jsonify({'ok': True, 'token': tok, 'ttl': _TOKEN_TTL})


def _row_public(r):
    now = _now()
    st = _status_of(r, now)
    exp = int(r.get('expire_at') or 0)
    remain = max(0, exp - now) if exp else 0
    return {
        'key': r.get('key_code'),
        'note': r.get('note') or '',
        'duration_h': int(r.get('duration_h') or 0),
        'status': st,
        'created_at': int(r.get('created_at') or 0),
        'activated_at': int(r.get('activated_at') or 0),
        'expire_at': exp,
        'remain': remain,
        'permanent': exp == 0 and int(r.get('activated_at') or 0) > 0,
        'device_id': r.get('device_id') or '',
        'last_ip': r.get('last_ip') or '',
        'last_seen': int(r.get('last_seen') or 0),
        'use_count': int(r.get('use_count') or 0),
    }


@license_bp.route('/admin/api/list', methods=['GET'])
def admin_list():
    if not _check_token():
        return _deny()
    q = _norm_key(request.args.get('q', ''))
    f = (request.args.get('status') or '').strip()
    try:
        limit = min(1000, max(1, int(request.args.get('limit', 500))))
    except Exception:
        limit = 500

    sql = 'SELECT * FROM license_keys'
    params = []
    if q:
        # 忽略横线：'ABCD-EFGH' 与 'ABCDEFGH' 都能搜到
        sql += " WHERE REPLACE(key_code, '-', '') LIKE ? OR note LIKE ?"
        params += ['%' + q + '%', '%' + request.args.get('q', '').strip() + '%']
    sql += ' ORDER BY id DESC LIMIT ' + str(limit)
    try:
        rows = database.query_all(sql, tuple(params)) or []
    except Exception as e:
        return jsonify({'ok': False, 'msg': '数据库错误: %s' % e}), 200

    items = [_row_public(r) for r in rows]
    if f:
        items = [x for x in items if x['status'] == f]

    # 统计（全库，不受筛选影响）
    try:
        all_rows = database.query_all('SELECT * FROM license_keys') or []
    except Exception:
        all_rows = []
    stats = {'total': 0, 'unused': 0, 'active': 0, 'expired': 0, 'disabled': 0}
    for r in all_rows:
        stats['total'] += 1
        stats[_status_of(r)] += 1
    return jsonify({'ok': True, 'items': items, 'stats': stats})


@license_bp.route('/admin/api/create', methods=['POST'])
def admin_create():
    if not _check_token():
        return _deny()
    req = request.get_json(force=True, silent=True) or {}
    try:
        count = int(req.get('count') or 1)
    except Exception:
        count = 1
    count = max(1, min(500, count))
    try:
        duration_h = int(req.get('duration_h') or 0)
    except Exception:
        duration_h = 0
    duration_h = max(0, min(24 * 365 * 20, duration_h))
    note = str(req.get('note') or '')[:190]

    created = []
    now = _now()
    for _ in range(count):
        for _try in range(6):
            k = _gen_key()
            try:
                database.execute(
                    'INSERT INTO license_keys(key_code,note,duration_h,created_at,'
                    'activated_at,expire_at,device_id,last_ip,last_seen,use_count,status) '
                    'VALUES (?,?,?,?,0,0,?,?,0,0,?)',
                    (k, note, duration_h, now, '', '', 'unused'))
                created.append(k)
                break
            except Exception:
                continue
    _log('CREATE', 'x%d %dh %s' % (len(created), duration_h, note))
    return jsonify({'ok': True, 'keys': created, 'duration_h': duration_h, 'count': len(created)})


@license_bp.route('/admin/api/action', methods=['POST'])
def admin_action():
    if not _check_token():
        return _deny()
    req = request.get_json(force=True, silent=True) or {}
    key = _fmt_key(req.get('key'))
    action = (req.get('action') or '').strip()
    if not key:
        return jsonify({'ok': False, 'msg': '缺少卡密'}), 200

    row = database.query_one('SELECT * FROM license_keys WHERE key_code = ?', (key,))
    if not row:
        return jsonify({'ok': False, 'msg': '卡密不存在'}), 200

    if action == 'disable':
        database.execute('UPDATE license_keys SET status = ? WHERE key_code = ?', ('disabled', key))
    elif action == 'enable':
        now = _now()
        exp = int(row.get('expire_at') or 0)
        database.execute(
            'UPDATE license_keys SET status = ? WHERE key_code = ?',
            ('expired' if (exp and now > exp) else ('active' if row.get('activated_at') else 'unused'), key))
    elif action == 'unbind':
        # 解绑设备 = 允许换机；已激活时间/到期时间保持不变
        database.execute('UPDATE license_keys SET device_id = ? WHERE key_code = ?', ('', key))
    elif action == 'reset':
        # 重置成未激活（重新计时用）
        database.execute(
            'UPDATE license_keys SET activated_at = 0, expire_at = 0, device_id = ?, '
            'use_count = 0, status = ? WHERE key_code = ?', ('', 'unused', key))
    elif action == 'extend':
        try:
            hours = int(req.get('hours') or 0)
        except Exception:
            hours = 0
        exp = int(row.get('expire_at') or 0)
        if exp:
            database.execute('UPDATE license_keys SET expire_at = ? WHERE key_code = ?',
                             (exp + hours * 3600, key))
    elif action == 'delete':
        database.execute('DELETE FROM license_keys WHERE key_code = ?', (key,))
    else:
        return jsonify({'ok': False, 'msg': '未知操作'}), 200

    _log('ACTION', '%s %s' % (action, key))
    return jsonify({'ok': True})


# ---------------------------------------------------------------- 客户端校验

@license_bp.route('/key/verify', methods=['POST'])
def key_verify():
    req = request.get_json(force=True, silent=True) or {}
    cfg = load_config()

    if cfg.get('license_enabled') is False:
        return jsonify({'ok': True, 'permanent': True, 'expire_at': 0, 'remain': 0,
                        'msg': '校验已关闭', 'bypass': True})

    key = _fmt_key(req.get('key'))
    device = str(req.get('device_id') or '')[:64]
    if not key:
        return jsonify({'ok': False, 'code': 'empty', 'msg': '请输入卡密'})

    try:
        row = database.query_one('SELECT * FROM license_keys WHERE key_code = ?', (key,))
    except Exception as e:
        return jsonify({'ok': False, 'code': 'dberr', 'msg': '服务器繁忙，请重试'})

    if not row:
        _log('VERIFY-FAIL', '%s 不存在' % key)
        return jsonify({'ok': False, 'code': 'invalid', 'msg': '卡密不存在'})

    now = _now()

    if (row.get('status') or '') == 'disabled':
        _log('VERIFY-FAIL', '%s 已停用' % key)
        return jsonify({'ok': False, 'code': 'disabled', 'msg': '卡密已被停用'})

    if (row.get('status') or '') == 'unbound':
        # ★ 一卡一机：客户在手机上自助解绑后该卡即作废，不能再绑任何设备
        #   （需要"解绑后允许换机"时，把 config.json 的 license_rebind_after_unbind 设为 true）
        _log('VERIFY-FAIL', '%s 已解绑作废' % key)
        return jsonify({'ok': False, 'code': 'unbound',
                        'msg': '该卡密已解绑作废，不能再次使用'})

    bind = cfg.get('license_bind_device', True)
    activated = int(row.get('activated_at') or 0)
    expire = int(row.get('expire_at') or 0)
    bound = row.get('device_id') or ''

    if not activated:
        duration_h = int(row.get('duration_h') or 0)
        expire = 0 if duration_h <= 0 else now + duration_h * 3600
        bound = device if (bind and device) else ''
        database.execute(
            'UPDATE license_keys SET activated_at = ?, expire_at = ?, device_id = ?, '
            'status = ? WHERE key_code = ?', (now, expire, bound, 'active', key))
    else:
        if bind and bound and device and bound != device:
            _log('VERIFY-FAIL', '%s 已绑定其它设备 %s != %s' % (key, bound, device))
            return jsonify({'ok': False, 'code': 'bound', 'msg': '该卡密已绑定其它设备'})
        if expire and now > expire:
            database.execute('UPDATE license_keys SET status = ? WHERE key_code = ?', ('expired', key))
            _log('VERIFY-FAIL', '%s 已过期' % key)
            return jsonify({'ok': False, 'code': 'expired', 'msg': '卡密已过期'})
        # 之前被解绑过（本机自助解绑 / 管理台解绑）→ 重新绑定当前设备
        if bind and device and not bound:
            database.execute('UPDATE license_keys SET device_id = ? WHERE key_code = ?', (device, key))

    database.execute(
        'UPDATE license_keys SET last_seen = ?, last_ip = ?, use_count = use_count + 1 '
        'WHERE key_code = ?',
        (now, str(request.headers.get('X-Forwarded-For', request.remote_addr or ''))[:64], key))

    remain = max(0, expire - now) if expire else 0
    _log('VERIFY-OK', '%s remain=%s' % (key, remain))
    return jsonify({
        'ok': True,
        'permanent': expire == 0,
        'expire_at': expire,
        'remain': remain,
        'msg': '永久有效' if expire == 0 else '激活成功',
    })


@license_bp.route('/key/unbind', methods=['POST'])
def key_unbind():
    """手机端自助解绑。

    客户换手机 / 重装系统后在**原手机**上点一下就能解绑，新手机即可重新激活，
    不必再找服主。安全性：必须卡密 + 与本机一致的 device_id 才能解绑；
    别人拿到卡密但设备不符时拒绝（防止盗卡者把设备顶掉）。
    解绑只清 device_id，**保留 activated_at / expire_at** —— 换机不重新计时。
    """
    req = request.get_json(force=True, silent=True) or {}
    key = _fmt_key(req.get('key'))
    device = str(req.get('device_id') or '')[:64]
    if not key:
        return jsonify({'ok': False, 'code': 'empty', 'msg': '请输入卡密'})

    try:
        row = database.query_one('SELECT * FROM license_keys WHERE key_code = ?', (key,))
    except Exception:
        return jsonify({'ok': False, 'code': 'dberr', 'msg': '服务器繁忙，请重试'})

    if not row:
        return jsonify({'ok': False, 'code': 'invalid', 'msg': '卡密不存在'})
    if (row.get('status') or '') == 'disabled':
        return jsonify({'ok': False, 'code': 'disabled', 'msg': '卡密已被停用'})

    bound = row.get('device_id') or ''
    if bound and device and bound != device:
        _log('UNBIND-FAIL', '%s 设备不符 %s != %s' % (key, device, bound))
        return jsonify({'ok': False, 'code': 'notowner', 'msg': '该卡密绑定的是另一台设备'})

    cfg = load_config()
    if cfg.get('license_rebind_after_unbind') is True:
        # 允许换机：只清设备，时间继续走
        database.execute("UPDATE license_keys SET device_id = '' WHERE key_code = ?", (key,))
        _log('UNBIND-OK', '%s 由 %s 解绑（可换机）' % (key, device or '未知设备'))
        return jsonify({'ok': True, 'msg': '已解绑本机，换新设备后输入卡密即可重新激活'})

    # ★ 默认行为：解绑 = 作废，该卡不能再绑任何设备（一卡一机）
    database.execute("UPDATE license_keys SET device_id = '', status = 'unbound' "
                     "WHERE key_code = ?", (key,))
    _log('UNBIND-OK', '%s 由 %s 解绑并作废' % (key, device or '未知设备'))
    return jsonify({'ok': True, 'msg': '已解绑本机，该卡密已作废，不能再绑定其它设备'})
