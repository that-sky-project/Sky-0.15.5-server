# route/service.py
import json
import os
import sys
import time
import glob
from flask import Blueprint, request, jsonify, send_from_directory
from datetime import datetime

# 导入统一数据库模块
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import db as database

# 创建蓝图
service_bp = Blueprint('service', __name__, url_prefix='/service')

# ---------- 工具函数 ----------
def load_config():
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
    with open(config_path, encoding="utf-8") as f:
        return json.load(f)


def _merge_reported_unlocks(user_id, payload, list_key):
    """兜底：把库里客户端上报过的解锁项并回 all_unlock_status.json 的返回。

    见 route/account.py 的同名函数说明 —— 修「神殿冥想点坐下不传送」的根因
    （客户端上报过 HubStatueForm，但静态配置表里漏了这一项）。
    """
    if not user_id:
        return payload
    try:
        raw = database.get_user_field(user_id, "unlocks")
    except Exception:
        return payload
    if not raw:
        return payload
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "ignore")
    try:
        reported = json.loads(raw) or []
    except (TypeError, ValueError):
        return payload

    items = payload.get(list_key) or []
    have = {u.get("name") for u in items if isinstance(u, dict)}
    for it in reported:
        if not isinstance(it, dict):
            continue
        name = it.get("name")
        if not name or name in have:
            continue
        have.add(name)
        entry = {
            "name": name,
            "type": it.get("type", "level"),
            "ack": True,
            "unlocked_at": it.get("unlocked_at", 0),
        }
        if "cost" in it:
            entry["cost"] = it["cost"]
        items.append(entry)
    payload[list_key] = items
    return payload

# ============================================================
# /service/message/ 路由
# ============================================================

@service_bp.route("/message/api/v1/get_all", methods=["POST"])
def get_all_messages():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user") or ""

    msg_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "mail_and_messages")
    files = glob.glob(os.path.join(msg_dir, "*.json"))

    messages = []
    for fp in files:
        with open(fp, encoding="utf-8") as f:
            msg = json.load(f)
            msg.setdefault("payload", {}) \
               .setdefault("headers", {})["to"] = user
            messages.append(msg)

    return jsonify({"status": "OK", "messages": messages})

@service_bp.route("/message/api/v2/get_all", methods=["POST"])
def get_all_messages_v2():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user") or ""

    msg_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "mail_and_messages")
    files = glob.glob(os.path.join(msg_dir, "*.json"))

    messages = []
    for fp in files:
        with open(fp, encoding="utf-8") as f:
            msg = json.load(f)
            msg.setdefault("payload", {}) \
               .setdefault("headers", {})["to"] = user
            messages.append(msg)

    return jsonify({"status": "OK", "messages": messages})

@service_bp.route("/message/api/v1/mark_received", methods=["POST"])
def mark_received():
    cfg = load_config()
    return send_from_directory(
        directory=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config'),
        path='mail_config.json',
        mimetype='application/json'
    )

@service_bp.route("/message/api/v1/mark_seen", methods=["POST"])
def mark_seen():
    req = request.get_json(force=True, silent=True) or {}
    ids = [m.get("id") for m in req.get("messages", [])]

    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "mail_config.json")
    if not os.path.isfile(cfg_path):
        return jsonify({"status": "OK", "messages": []}), 404

    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)

    matched = []
    for msg in cfg.get("messages", []):
        if msg.get("payload", {}).get("headers", {}).get("id") in ids:
            matched.append({
                "payload": {
                    "headers": {
                        "id": msg["payload"]["headers"]["id"],
                        "seen_at": int(time.time())
                    }
                }
            })

    return jsonify({"status": "OK", "messages": matched})

@service_bp.route("/message/api/v1/get", methods=["POST"])
def v1get():
    req = request.get_json(force=True, silent=True) or {}
    msg_id = req.get("message", {}).get("id")

    if not msg_id:
        return jsonify({"status": "OK", "messages": []}), 400

    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "mail_config.json")
    if not os.path.isfile(cfg_path):
        return jsonify({"status": "OK", "messages": []}), 404

    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)

    for msg in cfg.get("messages", []):
        if msg.get("payload", {}).get("headers", {}).get("id") == msg_id:
            return jsonify({
                "status": "OK",
                "messages": [
                    {
                        "payload": {
                            "headers": {
                                "id": msg_id,
                                "seen_at": int(time.time())
                            }
                        }
                    }
                ]
            })

    return jsonify({"status": "OK", "messages": []})

# ============================================================
# /service/status/ 路由
# ============================================================

@service_bp.route("/status/api/v1/get_unlocks", methods=["POST"])
def get_unlocks_status():
    cfg = load_config()

    if cfg.get("all_users_allunlock", False):
        # ★ 全解锁，但首次账号（未到过遇境）剔除"遇境到达"标记
        req = request.get_json(force=True, silent=True) or {}
        user_id = req.get("user")
        first_time = False
        if user_id:
            try:
                first_time = not int(database.get_user_field(user_id, "visited_home") or 0)
            except Exception:
                first_time = False
        base_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")
        with open(os.path.join(base_dir, "all_unlock_status.json"), encoding="utf-8-sig") as _f:
            payload = json.load(_f)
        if first_time:
            forbid = {"first_loaded_CandleSpace", "first_loaded_SkyHub2", "SkyHubFirstArrival",
                      "first_loaded_HubReveal", "1stHub", "DayHub", "FinishedIntro"}
            payload["status_unlocks"] = [u for u in payload.get("status_unlocks", []) if u.get("name") not in forbid]
        # ★ 兜底：把客户端上报过的解锁项并回来（修「神殿坐下不传送」）
        payload = _merge_reported_unlocks(user_id, payload, "status_unlocks")
        if isinstance(payload.get("status_unlocks"), list) and "status_unlocks_total_count" in payload:
            payload["status_unlocks_total_count"] = len(payload["status_unlocks"])
        return jsonify(payload)

    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    if not user:
        return jsonify({"error": "No user provided"}), 400

    if not database.user_exists(user):
        return jsonify({"error": "User not found"}), 404

    raw_data = database.get_user_field(user, "unlocks")
    data = json.loads(raw_data) if raw_data else []

    unlocks = [
        {
            "name": item.get("name", ""),
            "type": "level",
            "ack": item.get("ack", False),
            "unlocked_at": item.get("unlocked_at", 0)
        }
        for item in data
    ]

    return jsonify({
        "status_unlocks": unlocks,
        "status_unlocks_total_count": len(unlocks)
    })

@service_bp.route("/status/api/v1/delete_unlock", methods=["POST"])
def delete_unlock():
    return jsonify({})

@service_bp.route("/status/api/v1/add_unlock", methods=["POST"])
def add_unlock():
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user")
    name = req.get("name")
    ack = req.get("ack")

    if not user or name is None or ack is None:
        return jsonify({}), 400

    if not database.user_exists(user):
        return jsonify({}), 404

    raw_data = database.get_user_field(user, "unlocks")
    unlocks = json.loads(raw_data) if raw_data else []

    unlocked_at = int(datetime.utcnow().timestamp())
    unlocks.append({"name": name, "ack": ack, "unlocked_at": unlocked_at})

    database.set_user_field(user, "unlocks", json.dumps(unlocks))

    # ★ 客户端首次加载遇境会记录 first_loaded_CandleSpace / first_loaded_SkyHub2
    #   （SkyHub2 与 CandleSpace 同图别名）→ 标记"到过遇境"
    if name in ("first_loaded_CandleSpace", "first_loaded_SkyHub2", "SkyHubFirstArrival"):
        database.set_user_field(user, "visited_home", 1)

    return jsonify({})

# ---------- Catch-All 兜底路由 ----------
# 未实现的 /service/ 接口返回空 JSON，避免客户端按钮消失

@service_bp.route("/", defaults={"path": ""}, methods=["POST", "GET"])
@service_bp.route("/<path:path>", methods=["POST", "GET"])
def service_catch_all(path):
    return jsonify({}), 200