#!/usr/bin/env python3
"""生成 config/all_wing_buffs.json —— 给全服玩家「满光翼」。

原理
----
config.json 里 `all_user_allhaswingbuff = true` 时，
`POST /account/wing_buffs/get` 会把 config/all_wing_buffs.json 原样返回，
不再读数据库。所以「全服默认多少翼」= 这个文件里 collected=true 的条目数。

光翼 ID 的命名规则（与服务端/客户端一致的约定）：
    l_<领域名>_<序号>
领域名用客户端关卡目录里真实存在的 7 个领域（见 Sky-RE 解包
assets/scripts/Data/Levels/*/Resources.lua 中引用 Wingbuff.level 的关卡）：

    Dawn 晨岛 / Prairie 云野 / Rain 雨林 / Sunset 霞谷
    Dusk 暮土 / Night 禁阁 / Storm 暴风眼

用法
----
    python3 tools/gen_wing_buffs.py                # 默认 255 翼
    python3 tools/gen_wing_buffs.py --count 120    # 生成 120 翼
    python3 tools/gen_wing_buffs.py --dry-run      # 只打印分布不写文件
    python3 tools/gen_wing_buffs.py --out x.json
"""

import argparse
import json
import os
import sys

# 领域名, 起始序号, 权重（用于按比例分配总数）
REALMS = [
    ("Dawn",    0),
    ("Prairie", 1),   # 线上现网文件用的是 1 起的序号，保留以兼容
    ("Rain",    0),
    ("Sunset",  0),
    ("Dusk",    0),
    ("Night",   0),
    ("Storm",   0),
]

# 真实存在的默认光翼（现网生产文件里的原始 20 条），必须原样保留
KNOWN_REAL = (
    [f"l_Dawn_{i}" for i in range(0, 5)]
    + [f"l_Prairie_{i}" for i in range(1, 16)]
)


def build(count: int):
    """把 count 条光翼尽量均匀地分给 7 个领域。"""
    n_realms = len(REALMS)
    base, extra = divmod(count, n_realms)

    names = []
    for idx, (realm, start) in enumerate(REALMS):
        # 前 extra 个领域多分 1 条，保证总数精确等于 count
        take = base + (1 if idx < extra else 0)
        names.extend(f"l_{realm}_{start + i}" for i in range(take))

    # 去重（Dawn/Prairie 的已知条目本来就在范围内），并保证已知条目都在
    seen, ordered = set(), []
    for n in names + KNOWN_REAL:
        if n not in seen:
            seen.add(n)
            ordered.append(n)

    # 如果去重后不够数（正常不会），按领域继续补
    if len(ordered) < count:
        i = 0
        while len(ordered) < count:
            realm, start = REALMS[i % n_realms]
            cand = f"l_{realm}_{start + 900 + i // n_realms}"
            if cand not in seen:
                seen.add(cand)
                ordered.append(cand)
            i += 1

    ordered = ordered[:count]
    return [
        {
            "name": n,
            "collected": True,
            "deposited": False,
            "last_conversion": 0,
            "deposit_id": 0,
        }
        for n in ordered
    ]


def main():
    ap = argparse.ArgumentParser(description="生成 all_wing_buffs.json（全服满光翼）")
    ap.add_argument("--count", type=int, default=255, help="光翼总数（默认 255）")
    ap.add_argument("--out", default=None, help="输出路径（默认 config/all_wing_buffs.json）")
    ap.add_argument("--dry-run", action="store_true", help="只打印分布，不写文件")
    args = ap.parse_args()

    if not 1 <= args.count <= 9999:
        sys.exit("count 需在 1..9999 之间")

    here = os.path.dirname(os.path.abspath(__file__))
    out = args.out or os.path.join(os.path.dirname(here), "config", "all_wing_buffs.json")

    buffs = build(args.count)

    # 按领域统计，便于核对
    stat = {}
    for b in buffs:
        realm = b["name"].split("_")[1]
        stat[realm] = stat.get(realm, 0) + 1
    print(f"共 {len(buffs)} 条，分布：" + ", ".join(f"{k}={v}" for k, v in stat.items()))

    if args.dry_run:
        print("前 6 条示例：", json.dumps(buffs[:6], ensure_ascii=False))
        return

    with open(out, "w", encoding="utf-8") as f:
        json.dump({"result": "ok", "wing_buffs": buffs}, f, indent=4, ensure_ascii=False)
        f.write("\n")
    print(f"已写入 {out}")


if __name__ == "__main__":
    main()
